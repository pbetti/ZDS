/*
 *	old style global file
 */








#include "asm.h"
/*	GLOBAL file structure   */
#define	GBL	struct	gblx

struct gblx
{
	char	g_head;
	char	g_length;
	char	g_flag1;
	char	g_flag2;
	short	g_value;
	char	g_name[13];
};

#define	GBSIZE	19		/* number of bytes in old .gbl file */
static	char	eof;
FILE 	*oefile;


/*	This is the routine that reads in an EXTernal file and adds
 *	the labels and values to the symbol table.
 */

void old_global(buffer)
char	*buffer;
{
	register SYM	*sp;
	register GBL	*gp;
	register unsigned char	*tp;
	register int	i;
		 char	flag;
		 unsigned char	xbuff[80];


	if((oefile = tryopen(buffer)) == NULL)
	{
		tp = look(buffer);
		(void) sprintf(xbuff, "/usr/include/%s", tp);

		if((oefile = tryopen(xbuff)) == NULL)
		{
			printf("Open failure on GBL file: %s and %s\n", buffer, xbuff);
			return;
		}

		(void) strcpy(buffer, xbuff);
	}

	printl("reading old style global file\n");
	flag = 0;
	eof = 0;
	gp = (GBL *)xbuff;

	while(!eof)
	{
		tp = xbuff;

		for(i = 0; i < GBSIZE; i++)
			*tp++ = get_byte();
		
		if (flag && gp->g_name[0])
		{
			if (loc_symbol(gp->g_name) == 0)
			{
				sp = add_symbol();
				(void) movbuf(gp->g_name, sp->s_name, slenth, -1);
				sp->s_flag1 = SYMDFL | (gp->g_flag1 & SYMSEC);
				sp->s_flag2 = gp->g_flag2;
				sp->s_value = gp->g_value;
				sp->s_psect = pdef;
				sp->ref_beg = NULL;
				sp->ref_end = NULL;
 			}
		}
	
		flag = 1;
	}

	(void) fclose(oefile);
	oefile = NULL;
}




char get_byte()
{
	char	byte;
	int	x;

	for(;;)
	{
		if((x = fgetc(oefile)) <= 0)
		{
			eof = 1;
			return((char) 0);
		}

		if(x == '\n' || x == ':')
			continue;

		x -= x > '9' ? '7' : '0';
		byte = x << 4;
		x = fgetc(oefile);
		x -= x > '9' ? '7' : '0';
		return(byte |= x);
	}

	/*NOTREACHED*/
	return((char) 0);
}

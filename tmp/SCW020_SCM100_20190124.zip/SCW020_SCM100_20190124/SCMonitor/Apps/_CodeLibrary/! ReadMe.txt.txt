This folder contains source code modules common to many SCMonitor Apps.

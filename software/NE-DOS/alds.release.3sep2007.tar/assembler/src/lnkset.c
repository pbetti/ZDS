/*	File:	lnkset.c
 *
 *	Contains:	lnkset
 *
 *	This is the handler for the LNKSET pseudo-op.
 */




#include "asm.h"





void lnkset(token)
register unsigned char	token;
{

#if DEBUG
printf("link set\n");
#endif


	switch(token)
	{
	case 0:
		odint1 = 256;

	case 0x90:
		if (is_on(AFASEG))
		{
			odint2 = odint1;
			odint1 = adrefc[mode];
			locat();
			return;
		}

		if (passno == 1)
			return;

		if (adrefc[mode])
		{
			eror('S');
			return;
		}

		if (objfile)
		{
			clsrec();
			putX(OAH);
			putX(2);
			putX(odint1 & BYTMSK);
			putX((odint1 >> 8) & BYTMSK);
		}

		break;

	default:
		dnops();
	}
}

#define	IMD	struct	imed_record

struct imed_record
{
	SYM		*i_SYM;
	MAC		*i_mp_ptr;
	unsigned char	i_ortkbf[2];
	char		i_nrands;
	char		*i_savmac;
	unsigned char	i_mathfg;
	unsigned char	i_hilow;
	unsigned int	i_hladdr;
	char		i_errbuf[2];
	char		*i_op_start[2];
	unsigned char	i_opbyt1;
	unsigned int	i_odint1;
	unsigned char	i_opbyt2;
	unsigned int	i_odint2;
};

#define ISIZE sizeof(IMD)

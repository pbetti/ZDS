/*
 *
 *	Contains:	grp50
 *
 *	This is the handler for FILL and NOFILL.
 */




#include "asm.h"




void grp50()
{
#if DEBUG
printf("group 50\n");
#endif
	if (false_condit)
		return;

	filflg = ortkbf[1];
}

/*	File:	initp.c
 *
 *	Contains:	initp, initl
 *
 *	Init the assembler for a pass. This routine is called between
 *	passes to clear out and initialize the necessary variables
 */




#include "asm.h"


extern	int	pass1;
extern	char	lst_rel_tick;

void initp()
{
	int	i;

#if DEBUG
printf("initp\n");
#endif

	ifcnt = 0;		/* 'if' counter */
	false_condit = 0;	/* conditional flag */
	condi1 = 0;		/* 2nd conditional flag */
	litcnt = 0;		/* litorg literal counter */
	plchg = 0;		/* plit radix */
	hdflag = 0;		/* '06' header flags */
	idef = 0;		/* isect definition number */
	pfirst = 0;		/* psect first time switch */
	pdef = 0;		/* psect number is zero */
	filflg = 0;		/* 'fill' flag */
	lstoff = 0;		/* listing flags */
	print_short = 0;	/* short/long listing */
	print_mac = 1;		/* macro listing control flag */
	print_con = 0;		/* conditional listing flag */
	errcnt = 0;		/* assembler error counter */
	litnum = 0;		/* literal number */

	for(i = 0; i < SEGMENTS; i++)
		adrefc[i] = 0;	/* clear all pc counters */

	addisr = 0;		/* pc for listing counter */
	offset = 0;		/* phase (setloc) offset */
	eaddr = 0;		/* '06' header address */
	plchg = 0;		/* radix switch */
	bycnt = 0;		/* byte count of program */
	locnum = 1;		/* local label number */
	mlocnum = 1;		/* macro local label number */
	radix = 10;		/* current evaulation radix (base) */
	sline = 1;		/* listing line number */
	page = 1;		/* listing page number */

	if (pass1 && passno == 2)
		ffeed();

	encode = 0x55;		/* defe encript default value */
	flpseg = 0;		/* block comment flag */
	aflags = AFASEG;	/* start in absolute mode */
	mode = ASEG;
	file_no = 1;		/* reset current file number */
	filenum = 1;		/* reset file counter */
}



/*
 *	Init the assembler for a line. This routine is called between
 *	lines to clear out and initialize the necessary variables
 */


void initl(flag)
int	flag;
{
#if DEBUG
printf("initl\n");
#endif


	p1proc();		/* process the 06 headers' */

	if (!flag)
		errbuf[0] = SPACE;	/* reset the error buffer */
		
	ascdno = 0;		/* number of bytes in code buffer */
	opbyt1 = 0;		/* operand token 1 */
	opbyt2 = 0;		/* operand token 2 */
	patflg = 0;		/* patch flag */
	adroff = 0;		/* address offset */
	mathfg = 0;		/* math flags */
	hilow = 0;		/* high/low flags */
	lglob = 0;		/* global flag */
	bglob = 0;
	refpno = 0;
	odint1 = 0;		/* operator token 1 */
	odint2 = 0;		/* operator token 2 */
	hladdr = 0;		/* high/low buffer */
	dont = 0;		/* do/dont list, output, etc */
	adjflg = 0;		/* flag for adjust pc */
	labflg = 0;		/* flag for processed label */
	ortkbf[0] = 0;		/* operator token buffer */
	ortkbf[1] = 0;
	outchg = O4H;		/* reset the 04 header byte */
	false_condit = condi1;	/* reset the primary condition flag */
	lstcnt = LBYTES;	/* reset the listing byte count */

	if(lst_rel_tick != '^')
		lst_rel_tick = ' ';	/* reset listing relo tick */

	psave = pdef;		/* insure listing match of psect */
	adrefc[mode] &= (unsigned) 0xffff;
	addisr = adrefc[mode];

	turn_off(AFENDS | AFEQDL | AFHILO | AFLINK | AFEXTS |
		 AFENTS | AFUSPR | AFSYMB | AFABSL | AFDEFM |
		 AFORG  | AFMLOC | AFGLAB | AFGLOC | AFO4HD |
		 AFDSEG);
}

/*	File:	printf.c
 *
 *	Contains:	printl
 *
 *	This is a general purpose display output routine. It is used
 *	instead of the normal 'printf' so that the video output can be
 *	shut off if the line length would exceed one line and cause
 *	video wrap.
 */



#include "link.h"

extern	FILE	*logfile;

static	unsigned int	c;




/*VARARGS*/
printl(fmt, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10)
char	*fmt;
int	*arg1, *arg2, *arg3, *arg4, *arg5, *arg6, *arg7, *arg8, *arg9, *arg10;
{
	register unsigned char	*pnt;
		 unsigned char	buff[300];


	(void) sprintf(buff, fmt, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	pnt = buff;

	while(*pnt)
	{
		++c;

		if(*pnt == '\n')
			c = 0;

		if(*pnt == '\t')
			c += c % 8;

		if(c >= 78)
		{
			++pnt;
			continue;
		}

		if(logfile)
			(void) putc(*pnt++, logfile);
		else
			(void) putchar(*pnt++);
	}

	if(logfile)
		fflush(logfile);
}

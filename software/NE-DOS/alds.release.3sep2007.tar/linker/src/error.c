/*	File:	error.c
 *
 *	Contains:	undefined, multiple
 *
 *	Error handler for the linker.
 */



#include "link.h"


extern	unsigned int	errcnt;
extern	unsigned int	fatal;
extern	unsigned int	warning;
extern	unsigned char	*who;
extern	unsigned char	*head2;
extern	FILE		*mapfile;





undefined(name)
unsigned char	*name;
{
	error(name, "Undefined External Symbol", FATAL);
}



multiple(name)
unsigned char	*name;
{
	error(name, "Multiply Defined Global Symbol", FATAL);
}



went_over(flag, value)
unsigned int	flag, value;
{
	register	char	*p;
			char	xbuff[30];


	switch(flag)
	{
	case 0:
		p = "psect";
		break;

	case 1:
		sprintf(xbuff, "defs of %04.4X", value);
		p = xbuff;
		break;

	case 2:
		p = "CODE";
		break;
	}


	error(p, "caused program counter wrap-around over 0FFFFH", WARNING);
}




different(name, adr1, adr2)
unsigned char	*name;
unsigned int	adr1, adr2;
{
	unsigned char	xbuffx[150];


	sprintf(xbuffx ,"Address diff  Pass 1: %04.4X  Pass 2: %04.4X", adr1, adr2);
	error(name, xbuffx, WARNING);
}




static error(name, mesg, level)
register unsigned char	*name, *mesg;
register unsigned int	level;
{
			unsigned char	xbuffx[150];
	register	unsigned char	*hold;


	printl("%-12s: %s in file %s\n", name, mesg, who);

	if(mapfile)
	{
		hold = head2;
		head2 = (unsigned char *) "Errors:";
		sprintf(xbuffx, "%-12s: %s in file %s", name, mesg, who);
		list(xbuffx);
		head2 = hold;
	}

	++errcnt;

	if(level == FATAL)
		++fatal;
	else	++warning;
}

/*	File:	litorg.c
 *
 *	Contains:	litorg
 *
 *	This it the litorg handler for dumping of the literal pool.
 */




#include "asm.h"


short	litxnum;


/*.
*************************************************************************
*									*
*									*
*									*
*									*
*									*
*************************************************************************
*/
void litorg()
{
	unsigned char	c;

#if DEBUG
printf("litorg\n");
#endif



	if (false_condit || !litcnt)
		return;

	c = (opbyt1 & 0xf0) | ((opbyt2 >> 4) & 0xf);

	if (c)
	{
		if (c != INTTOK)
		{
			eror('S');
			return;
		}

		porg(c);

		if (passno == 2 && objfile)
		{
			proces();
			putobj();
		}
	}

	if (passno == 2)
		lstln();

	pdlit();
	litcnt = 0;
	ascdno = 0;
	dont = 1;
}


/*.
*************************************************************************
*									*
*									*
*	This routine will process and store the litorg literals into	*
*	the literal pool. It is called from gtod.			*
*									*
*									*
*									*
*************************************************************************
*/
void prolit(lp)
register unsigned char *lp;
{
	register int	i;
	register LIT	*sp;


#if DEBUG
printf("prolit\n");
#endif

	if (false_condit)
		return;

	++litcnt;

	while(*lp == '=' || *lp == SQUOTE)
		++lp;
	
	if (!(i = lstr(lp)))
	{
		dnops();
		return;
	}

	clrbuf(tx2, 80);
	(void) movbuf(lp, tx2, i, -1);

	switch(passno)
	{
	case 1:
		if (!litcmp())
		{
			sp = litend;
			sp->l_number = ++litxnum;
			lp = movbuf(lp, sp->l_text, i, -1);
			*lp = 0;
			++sp;
			litend = sp;
		}

		break;

	case 2:
		sp = litcmp();
		(void) sprintf(tx3, "LX%u", sp->l_number);
		(void) psymb(tx3);
		opbyt2 = INTTOK;
		odint2 = evalue;
		setmth();
		break;
	}
}




/*	literal compare to see if literal is already in buffer */
LIT *litcmp()
{
	register LIT	*sp;

#if DEBUG
printf("litcmp\n");
#endif


	sp = litbeg;

	while(sp->l_number)
	{
		if (match(tx2, sp->l_text, -1))
			return(sp);

		++sp;
	}

	return(0);
}


/*.
*************************************************************************
*									*
*	str								*
*	---								*
*									*
*	return the length of an ascii text string			*
*									*
*	str(pnt)							*
*									*
*	<str> register char *pnt					*
*		pointer to ASCII text string				*
*									*
*	returns length of string					*
*									*
*************************************************************************
*/
int lstr(pnt)
register char *pnt;
{
	register int	count;

	count = 0;


	/* if we're pointing to the 1st quote, skip it */
	if (*pnt == SQUOTE)
		++pnt;

	/* get the count of the line */
	while(!term(pnt))
	{
		if (pnt[0] == SQUOTE && pnt[1] == SQUOTE)
		{
			count += 2;
			pnt += 2;
		}
		else if (*pnt == SQUOTE)
			break;
		else if (*pnt == '^')
			++pnt;
		else
		{
			++count;
			++pnt;
		}
	}

	return(count);
}


/*.
*************************************************************************
*									*
*									*
*	This is the literal handler that is called when 'litorg' is	*
*	declared, and at the end of the assembly for automatic literal	*
*	output.								*
*									*
*									*
*									*
*************************************************************************
*/
void pdlit()
{
	register LIT	*sp;
	register SYM	*symbol;

#if DEBUG
printf("pdlit\n");
#endif


	if (!litcnt || false_condit)
		return;

	initl(0);
	litcnt = 0;

	if (passno == 1)
		litnum = 0;

	sp = litbeg;

	while(sp->l_number)
	{
		initl(0);
		(void) strcpy(numbbb, "\t");
		(void) sprintf(labbuf, "LX%u", sp->l_number);
		labflg = 0;
		symbol = proc_symbol(DEFBTK,NULL);
		
		if (passno == 1)
			symbol->s_flag1 &= ~SYMUDF;
		
		(void) sprintf(minbuf, "LX%u:\tLIT\t'%s'", sp->l_number, sp->l_text);
		linpnt = minbuf;

		while(*linpnt)
			if (*linpnt++ == SQUOTE)
				break;

		--linpnt;
		ortkbf[1] = 1;
		defm();
		adjarc();

		if (passno == 2)
		{
			proces();
			lstln();

			if (objfile)
				putobj();
		}

		++sp;
	}

	dont = 1;
}

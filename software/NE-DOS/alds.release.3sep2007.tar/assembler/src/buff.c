/*	File:	buff.c
 *
 *	These are the storages and buffers for the assembler.
 */


#include "asm1.h"


FILE	*errfile = 0;
FILE	*imdfile = 0;
FILE	*lisfile = 0;
FILE	*logfile = 0;
FILE	*objfile = 0;
FILE 	*infile = 0;

LIT	litbuf[MAXLIT];		/* litorg buffer */
LIT	*litbeg = litbuf;	/* pointer to beginning of literals */
LIT	*litend = litbuf;	/* pointer to end of literals */

MAC	*macbeg = 0;		/* pointer to beginning of macros */
MAC	*macend = 0;		/* pointer to last macro */

SYM 	*symbeg = 0;		/* beginning of symbol table */


char	asscod[260];		/* assembly code buffer */
char	dateb[20];		/* date buffer */
char	errbuf[2];		/* error buffer */
char	hedbuf[100];		/* header buffer */
char	ifstk[10];		/* conditional stack */
char	labbuf[40];		/* label buffer */
char	lline[300];		/* listing line buffer */
char	minbuf[200];		/* disk line input buffer */
char	numbbb[7];		/* line number buffer */
char	o4entb[20];		/* 04 entry name buffer */
char	o4extb[20];		/* 04 external name buffer */
char	objbuf[800];		/* intel hex object code buffer */
char	objname[60];		/* buffer for object file name */
char	ortkbf[3];		/* operator token buffer */
char	pbuffr[20];		/* psect name buffer */
char	ptable[50];		/* psect header table */
char	savebuf[60];		/* buffer for source file name */
char	symbuf[40];		/* work buffer for token operations */
char	timeb[20];		/* time buffer */
char	titbuf[100];		/* title buffer */
char	tx1[300];		/* temp buffer 1 */
char	tx2[100];		/* temp buffer 2 */
char	tx3[100];		/* temp buffer 3 */
char	usin1[2];		/* using number buffer */

char	*incpnt = '\0';		/* pointer to include file name */
unsigned char	*linpnt;		/* pointer into input line buffer */

char	adjflg;			/* flag for adjust pc */
char	bglob;			/* flag for list routine */
char	condi1;			/* secondary conditional flag */
char	conflg;			/* flag shows conditionals on */
char	dont;			/* listing flag */
char	false_condit;		/* conditional flag */
char	filflg;			/* 'fill' flag */
char	flpseg;			/* block comment flag */
char	frstsw;			/* first time switch for chkhed() */
char	hdchg;			/* END header change */
char	hdflag;			/* '06' header flags */
char	idef;			/* present isect number */
char	isave2;			/* save for isect number check */
char	labflg;			/* flag for processed label */
char	lglob;			/* global flag */
char	line;			/* number of lines this page */
char	lstcnt = 6;		/* reset the listing byte count */
char	lstoff;			/* listing flags */
char	mode;			/* mode of the assembler */
char	opnrec;			/* flag to show open record */
char	outchg;			/* reset the 04 header byte */
char	parflg;			/* used by expression */
char	passno = 1;		/* assembler pass number */
char	patflg;			/* patch flag */
char	pdef;			/* present psect number */
char	pfirst;			/* psect first time switch */
char	plchg;			/* plit radix */
char	print_con = 0;		/* conditional listing flag */
char	print_mac;		/* macro listing control flag */
char	print_short;		/* int/long listing flag */
char	ps;			/* flag for multi psects */
char	psave;			/* insure listing match of psect */
char	radix = 10;		/* current evaulation radix (base) */
char	refflg;			/* flag to show we're in a ref */
char	refpno;			/* flag for symbol referenced */

int	addisr;			/* pc for listing counter */
int	adrefc[3];		/* pc counter */
int	adroff;			/* address offset */
int	ascdno;			/* number of bytes in code buffer */
int	bycnt;			/* byte count of program */
int	chksum;			/* checksum for intel hex output */
int	eaddr;			/* '06' header address */
int	encode;			/* encrypt value for DEFE */
int	entadr;			/* address for entry */
int	errcnt;			/* assembler error counter */
int	evalue;			/* value save */
int	fast;			/* no listing wanted flag */
int	file_no = 1;		/* current file number */
int	filenum = 1;		/* internal file number counter */
int	hilow;			/* high/low flags */
int	hladdr;			/* used for high/low */
int	ifcnt;			/* 'if' counter */
int	inccnt;			/* include counter */
int	isave;			/* address save for isect */
int	litcnt;			/* litorg literal counter */
int	litnum;			/* literal number */
int	locnum = 1;		/* local label number */
int	dolog;			/* nz = logfile being written */
int	macnum = 0;		/* number of macros */
int	mathfg;			/* math flags */
int	mlocnum = 1;		/* macro local label number */
int	o4cnt;			/* bytes in 04 header */
int	ocount;			/* object buffer count */
int	odint1;			/* operator token 1 */
int	odint2;			/* operator token 2 */
int	offset;			/* phase (setloc) offset */
int	opbyt1;			/* operand token 1 */
int	opbyt2;			/* operand token 2 */
int	page;			/* listing page number */
int	rlist;			/* display lines to video for test */
int	slenth;			/* length of a symbol */
int	sline;			/* number of source lines */
int	symcnt;			/* count for cross reference output */
int	topaddr;		/* highest address of pgm */

long	aflags;			/* assembler flags */

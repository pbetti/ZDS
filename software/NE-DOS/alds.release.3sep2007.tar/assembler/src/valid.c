/*	File:	valid.c
 *
 *	Contains:	alpnum, digit, alpha, chkspc,
 *			term, skipsp, tolower, toupper
 *
 *	See is a character is valid for use in a label
 */

#include "asm.h"
#include <ctype.h>
#define index strchr
#define rindex strrchr


char	*index();

int alpnum(ptr)
register char *ptr;
{
	if (digit(ptr))
		return(1);

	return(alpha(ptr));
}



int digit(ptr)
register char *ptr;
{
	if (isdigit(*ptr))
		return(1);

	return(0);
}


/*.
*************************************************************************
*									*
*									*
*									*
*									*
*									*
*************************************************************************
*/
int alpha(ptr)
register char *ptr;
{
	if(isalpha(*ptr))
		return(1);

	switch(*ptr)
	{
	case '?':
	case '_':
	case '$':
	case '@':
	case '#':
		return(1);
	}

	return(0);
}


/*.
*************************************************************************
*									*
*	notend								*
*	------								*
*									*
*	check for end of arguments (space, tab, 0, CRLF, or COMENT)	*
*									*
*	int notend(pnt)							*
*									*
*	<pnt> register char *pnt					*
*		pointer to character in question			*
*									*
*	returns 1 if character is not the end				*
*	returns 0 if character is a terminator				*
*									*
*************************************************************************
*/
int notend(pnt)
register char *pnt;
{
	if (chkspc(pnt))
		return(0);

	if (term(pnt))
		return(0);

	return(1);
}


/*.
*************************************************************************
*									*
*	chkspc								*
*	------								*
*									*
*	see if the character is a space or tab character		*
*									*
*	int chkspc(pnt)							*
*									*
*	<pnt> register char *pnt					*
*		pointer to character in question			*
*									*
*	returns 1 if character is a space or tab			*
*	returns 0 if not						*
*									*
*************************************************************************
*/
int chkspc(pnt)
register char *pnt;
{
	if (*pnt == SPACE || *pnt == HT)
		return(1);

	return(0);
}


/*.
*************************************************************************
*									*
*	term								*
*	----								*
*									*
*	see if the character is a terminator to line			*
*									*
*	int term(pnt)							*
*									*
*	<pnt> register char *pnt					*
*		pointer to character in question			*
*									*
*	returns 1 if character is a terminator			*
*	returns 0 if not						*
*									*
*************************************************************************
*/
int term(pnt)
register char *pnt;
{
	if (*pnt == 0x00 || *pnt == COMENT)
		return(1);

	return(0);
}



/*	skip spaces in a line buffer	*/

unsigned char *skipsp(pnt)
register unsigned char *pnt;
{
	while (*pnt == ' ' || *pnt == HT)
		pnt++;

	return(pnt);
}





/*.
*************************************************************************
*									*
*									*
*									*
*									*
*									*
*************************************************************************
*/

#ifdef atolower
#undef atolower
#endif

/*	convert character to lower case if it's upper	*/
char atolower(c)
char c;
{
	if (c >= 'A' && c <= 'Z')
		return(c + ' ');
	else
		return(c);
}



#ifdef atoupper
#undef atoupper
#endif

/*	convert character to upper case if it's lower	*/
char atoupper(c)
char c;
{
	if (c >= 'a' && c <= 'z')
		return(c - ' ');
	else
		return(c);
}


/*.
*************************************************************************
*									*
*									*
*									*
*									*
*									*
*************************************************************************
*/
char hexasc(byte)
unsigned char	byte;
{
	byte &= 0xf;

	if(byte > 9)
		byte += '7';
	else
		byte += '0';

	return(byte);
}




unsigned char *skipquote(ptr)
register unsigned char *ptr;
{
	return((unsigned char *)index(++ptr, '\''));
}

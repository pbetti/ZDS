/*	File:	link.c
 *
 *	Contains:	lib, xlink, glink
 *
 *	These are the handlers for LIB, LINK, and GLINK pseudo-ops.
 */




#include "asm.h"




void lib()
{
	link0(O9LIB | O9LNK);
}



void glink()
{
	link0(O9GBL | O9LNK);
}



void xlink()
{
	turn_on(LINKST);
	link0(O9LNK);
}



void link0(flag)
char flag;
{
	register unsigned char	*lp;
	register int	i;
		 char	length;
		 unsigned char	nbuff[50];

	if (false_condit)
		return;

	if (mode == ASEG)
	{
		eror('S');
		return;
	}

	if (passno == 1)
	{
		turn_on(AFLINK);
		return;
	}

#if DEBUG
printf("link\n");
#endif

	lstln();
	dont = 1;

	linpnt = skipsp(linpnt);

	if (*linpnt == SQUOTE)
		++linpnt;

	if ((length = str(linpnt)) == 0)
	{
		dnops();
		return;
	}

	if (objfile == NULL)
		return;

	(void) strncpy(nbuff, linpnt, length);

	if (lp = search(nbuff))
		*lp = 0;

	clsrec();
	putX(O9H);
	putX((unsigned char) slenth);
	putX(flag);
	lp = nbuff;

	for (i = 0; i < slenth; i++)
		putX((*lp) ? *lp++ : SPACE);
}

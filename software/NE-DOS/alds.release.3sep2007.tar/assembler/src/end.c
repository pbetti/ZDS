/*	File:	grp4.c
 *
 *	Contains:	grp4
 *
 *	This is the END statement handler.
 */




#include "asm.h"






void grp4(token)
char token;
{
	register int	number, addsave, hdsave;
		 char	terr;
		 char	tempx[180];


#if DEBUG
printf("group 4\n");
#endif


	if (inccnt)
		return;


	if (litcnt)
	{
		addsave = odint1 & (unsigned) 0xffff;
		hdsave = ortkbf[1];
		(void) strcpy(tempx, minbuf);
		number = atoi(numbbb);
		terr = errbuf[0];
		pdlit();
		odint1 = addsave;
		ortkbf[1] = hdsave;

		if (number == 99999)
			(void) sprintf(numbbb, "99999\t");
		else
			(void) sprintf(numbbb, "%5u\t", sline);

		(void) strcpy(minbuf, tempx);
		errbuf[0] = terr;
		dont = 0;
	}


	if (ifcnt || false_condit || condi1)
	{
		ifcnt = 0;
		false_condit = 0;
		condi1 = 0;
		eror('C');
	}


	turn_on(AFENDS | AFADIS | AFORG);
	lstoff = 0;
	hdchg = ortkbf[1];


	if (token)
		addisr = odint1 & (unsigned) 0xffff;
	else
		addisr = 0;
	
	topaddr = adrefc[mode];

	if (passno == 2 && objfile)
		endrec();
}

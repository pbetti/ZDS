

/*	File:	buff.c
 *
 *	These are the buffer storages for the linker
 */


#include "link.h"



FILE		*cmdfile;
FILE		*gblfile;
FILE		*infile;
FILE		*logfile;
FILE		*mapfile;
FILE		*objfile;

SYM		*symbas;
SYM		*symprv;

unsigned char	cmdline[100];
unsigned char	cname1[50];
unsigned char	cname2[50];
unsigned char	dateb[30];
unsigned char	filename[100];
unsigned char	gblname[30];
unsigned char	head1[100];
unsigned char	head2[100];
unsigned char	line[200];
unsigned char	listname[30];
unsigned char	logname[30];
unsigned char	mapname[30];
unsigned char	nullx[] = "";
unsigned char	objbuf[700];
unsigned char	objname[30];
unsigned char	sdate[30];
unsigned char	sourcename[30];
unsigned char	sxtime[30];
unsigned char	timeb[30];


unsigned char	chksum;
unsigned char	cmdflag;
unsigned char	opnrec;
unsigned char	mode;
unsigned char	passno;
unsigned char	*who;

unsigned int	addisr;
unsigned int	adrsav;
unsigned int	cmdaddress;
unsigned int	cmdpoint;
unsigned int	cvalue1;
unsigned int	cvalue2;
unsigned int	errcnt;
unsigned int	fatal;
unsigned int	fullflag;
unsigned int	hex_value;
unsigned int	inclf;
unsigned int	lastaddr;
unsigned int	lflag;
unsigned int	lineno;
unsigned int	log;
unsigned int	noload;
unsigned int	nopsect;
unsigned int	noref;
unsigned int	nosym;
unsigned int	ocount;
unsigned int	ofset1;
unsigned int	psectcount;
unsigned int	relo[2];
unsigned int	symcnt;
unsigned int	symmax;
unsigned int	topaddr;
unsigned int	transaddr;
unsigned int	ltruncate;
unsigned int	warning;
int		slenth;

unsigned int	adrefc[2];

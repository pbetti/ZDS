/*	File:	defm.c
 *
 *	Contains:	defm, dodate
 *
 *	This is the handler for the DEFM, DEFT, and DEFE pesudo-op.
 */




#include "asm.h"



void defm()
{
	register unsigned char	*lp;
	register short	lenx;
	register char	c;
	register unsigned char	*sp;

#if DEBUG
printf("defm\n");
#endif

	if (false_condit)
		return;

	lp = skipsp(linpnt);
	linpnt = lp;

	c = ortkbf[1];


	/* handle DEFR */
	if (c == 5)
	{
		defr();
		return;
	}

	/* handle everything that isn't DEFM, DEFT, or DEFE */
	if ((c > 1) && (c != 4))
	{
		dodate(c);
		return;
	}

	if ((lenx = str(lp)) == 0)
		return;

	lenx = (lenx > ACBSIZ+1 ? ACBSIZ : lenx);
	sp = asscod;

	if (c == 1 || c == 4)
	{
		sp[0] = lenx;
		ascdno = lenx + 1;
		(void) movbuf(lp, sp+1, lenx, c == 4 ? 2 : 1);
	}
	else
	{
		ascdno = lenx;
		(void) movbuf(lp, sp, lenx, 1);
	}
}



/*	handle date and time	*/
void dodate(c)
char c;
{
	register unsigned char	*lp;
	register short	xline;

#if DEBUG
printf("dodate\n");
#endif

	lp = c == 2 ? dateb : timeb;
	ascdno = 0;
	lstln();
	xline = sline;
	(void) strcpy(numbbb, "  -  \t");
	(void) sprintf(minbuf, "\tDEFM\t'%s'", lp);
	ortkbf[0] = DEFMTK;
	ortkbf[1] = 0;
	defm();
	lstln();
	dont = 1;
	sline = xline;
}

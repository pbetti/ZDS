#ifndef M68000
#define void int
#endif

#include "asm.h"


int (*z80_func[])() =
{
	dnops,			/*  0 NONE */
	set_ascdno,		/*  1 ORGTOK */
	set_ascdno,		/*  2 EQUTOK */
	set_ascdno,		/*  3 DEFLTK */
	grp4,			/*  4 ENDTOK */
	grp5,			/*  5 DEFBTK */
	grp6,			/*  6 DEFWTK */
	grp7,			/*  7 DEFSTK */
	defm,			/*  8 DEFMTK */
	title,			/*  9 TITTOK */
	grp11,			/* 10 SBTOK */
	grp11,			/* 11 DBTOK */
	grp12,			/* 12 AOXCS */
	grp13,			/* 13 IDTOK */
	grp14,			/* 14 IMTOK */
	grp15,			/* 15 RRSRR */
	grp16,			/* 16 BSRTOK */
	grp17,			/* 17 JPTOK */
	grp18,			/* 18 JRTOK */
	grp19,			/* 19 DJNZTK */
	grp20,			/* 20 CALLTK */
	grp21,			/* 21 RETTOK */
	grp22,			/* 22 RSTTOK */
	grp23,			/* 23 INTOK */
	grp24,			/* 24 OUTTOK */
	grp25,			/* 25 PUSHTK */
	grp26,			/* 26 EXTOK */
	grp27,			/* 27 ASTOK */
	grp28,			/* 28 ADDTOK */
	grp29,			/* 29 LDTOK */
	grp30,			/* 30 CONDTK */
	global,			/* 31 GLOBTK */
	grp32,			/* 32 SAVETK */
	gmacro,			/* 33 MACROT */
	grp34,			/* 34 CDCRTK */
	extsym,			/* 35 EXTRNT */
	entsym,			/* 36 ENTRYT */
	grp37,			/* 37 USINGT */
	grp38,			/* 38 RADIXT */
	litorg,			/* 39 LITORT */
	grp40,			/* 40 RSTRTK */
	grp41,			/* 41 SVCTOK */
	cmp,			/* 42 MOVTOK */
	grp43,			/* 43 ISECTK */
	grp44,			/* 44 ENDITK */
	grp45,			/* 45 DROPTK */
	apush,			/* 46 APUSHT */
	apop,			/* 47 APOPTK */
	cmp,			/* 48 CMPTOK */
	grp49,			/* 49 EXITOK */
	grp50,			/* 50 FILLTK */
	grp51,			/* 51 RRRRSS */
	reseld,			/* 52 SETLDT */
	tname,			/* 53 TKNAME */
	lnkset,			/* 54 LNKSTK */
	mlocal,			/* 55 LOCALT */
	ejecit,			/* 56 EJECT */
	xlink,			/* 57 LINK */
	header,			/* 58 HEADER, HEADING */
	set_ascdno,		/* 59 STOPIT */
	set_ascdno,		/* 60 SCREEN */
	set_ascdno,		/* 61 DUALON */
	set_ascdno,		/* 62 DUALOFF */
	set_ascdno,		/* 63 QUITIT */
	adisp,			/* 64 ADISP */
	refer,			/* 65 REF */
	incl,			/* 66 INCLUDE */
	etern,			/* 67 EXT */
	printv,			/* 68 PRINT */
	robj,			/* 69 OBJ */
	set_ascdno,		/* 70 PATCH */
	glink,			/* 71 GLINK */
	set_ascdno,		/* 72 VERSION */
	set_ascdno,		/* 73 XLOAD */
	set_ascdno,		/* 74 YLOAD */
	lib,			/* 75 LIB */
	grp52,			/* 76 TST */
	grp53,			/* 77 MULTIPLY */
	grp54,			/* 78 in0, out0 */
	0
};

/*
 *	This is the register lookup table.
 */
REG	reglst[] =
{
	"a",		0x77,
	"af",		0x17,
	"af'",		0xe0,
	"b",		0x70,
	"bc",		0x10,
	"c",		0x71,
	"d",		0x72,
	"de",		0x11,
	"e",		0x73,
	"f",		0xe6,
	"h",		0x74,
	"hl",		0x12,
	"i",		0x20,
	"ix",		0x1a,
	"iy",		0x1e,
	"l",		0x75,
	"m",		0x8f,
	"nc",		0x8a,
	"nv",		0x8c,
	"nz",		0x88,
	"p",		0x8e,
	"pe",		0x8d,
	"po",		0x8c,
	"r",		0x21,
	"sp",		0x13,
	"v",		0x8d,
	"xh",		0x78,
	"xl",		0x79,
	"yh",		0x7c,
	"yl",		0x7d,
	"z",		0x89,
};




BRACK	bracket[] =
{
	0x12,		0x40,		/* HL -> (HL) */
	0x1a,		0x48,		/* IX -> (IX) */
	0x1e,		0x4c,		/* IY -> (IY) */
	0x13,		0x50,		/* SP -> (SP) */
	0x11,		0x61,		/* DE -> (DE) */
	0x10,		0x60,		/* BC -> (BC) */
	0x71,		0xa0,		/*  C -> (C)  */
	0xca,		0xba,		/* IX+D -> (IX+D) */
	0xce,		0xbe,		/* IY+D -> (IY+D) */
	0x90,		0xd0,		/*  N -> (N)  */
	0,		0
};







/*
 *	mnemonic lookup table.
 *
 *	Note:	The structure TABLE allows for a maximum of 7 letters
 *		in the name field. If you add anything that is greater
 *		than 7 characters, be sure to bump up the number in the
 *		structure definition.
 */


TABLE	orlstp2[] =
{
/*
	symbol		token		# of operands	code
*/
	"=",		EQUTOK,		1,		0,
	"ld",		LDTOK,		2,		0,
	"jp",		JPTOK+CONBIT,	2,		0,
	"cp",		AOXCS,		1,		0x38,
	"in",		INTOK,		2,		0,
	"or",		AOXCS,		1,		0x30,
	"di",		SBTOK,		0,		0xf3,
	"ei",		SBTOK,		0,		0xfb,
	"im",		IMTOK,		1,		0,
	"rl",		RRSRR,		1,		0x10,
	"rr",		RRSRR,		1,		0x18,
	"jr",		JRTOK+CONBIT,	2,		0,
	"ex",		EXTOK,		2,		0,
	"cd",		CDCRTK,		2,		0x10,
	"cr",		CDCRTK,		2,		0x20,
	"tz",		CDCRTK,		1,		0x20,
	"db",		DEFBTK,		-1,		0,
	"dw",		DEFWTK,		-1,		0,
	"ds",		DEFSTK,		1,		0,
	"do",		SVCTOK,		1,		0,
	"if",		CONDTK,		1,		IFNZERO,
	0,		0,		0,		0
};


TABLE	orlstp3[] = 
{
/*
	symbol		token		# of operands	code
*/
	"inc",		IDTOK,		1,		0,
	"dec",		IDTOK,		1,		0x9,
	"out",		OUTTOK,		2,		0,
	"and",		AOXCS,		1,		0x20,
	"org",		ORGTOK,		1,		0,
	"equ",		EQUTOK,		1,		0,
	"end",		ENDTOK,		1,		0x2,
	"exx",		SBTOK,		0,		0xd9,
	"daa",		SBTOK,		0,		0x27,
	"cpl",		SBTOK,		0,		0x2f,
	"ccf",		SBTOK,		0,		0x3f,
	"scf",		SBTOK,		0,		0x37,
	"nop",		SBTOK,		0,		0,
	"rla",		SBTOK,		0,		0x17,
	"rra",		SBTOK,		0,		0x1f,
	"ldi",		DBTOK,		0,		0xa0,
	"ldd",		DBTOK,		0,		0xa8,
	"cpi",		DBTOK,		0,		0xa1,
	"cpd",		DBTOK,		0,		0xa9,
	"neg",		DBTOK,		0,		0x44,
	"rld",		DBTOK,		0,		0x6f,
	"rrd",		DBTOK,		0,		0x67,
	"ind",		DBTOK,		0,		0xaa,
	"ini",		DBTOK,		0,		0xa2,
	"xor",		AOXCS,		1,		0x28,
	"rlc",		RRSRR,		1,		0,
	"sla",		RRSRR,		1,		0x20,
	"slo",		RRSRR,		1,		0x30,
	"rrc",		RRSRR,		1,		0x8,
	"sra",		RRSRR,		1,		0x28,
	"srl",		RRSRR,		1,		0x38,
	"bit",		BSRTOK,		2,		0x40,
	"set",		BSRTOK,		2,		0xc0,
	"res",		BSRTOK,		2,		0x80,
	"ret",		RETTOK+CONBIT,	1,		0,
	"rst",		RSTTOK,		1,		0,
	"pop",		PUSHTK,		1,		0xc1,
	"adc",		ASTOK,		2,		0x8,
	"sbc",		ASTOK,		2,		0x10,
	"add",		ADDTOK,		2,		0,
	"sub",		AOXCS,		1,		0x10,
	"ift",		CONDTK,		1,		IFTRUE,
	"iff",		CONDTK,		1,		IFFALSE,
	"ifz",		CONDTK,		1,		IFZERO,
	"ifp",		CONDTK,		1,		IFPOS,
	"ifm",		CONDTK,		1,		IFNEG,
	"ref",		REFER,		3,		0,
	"ext",		EXTERN,		3,		0,
	"svc",		SVCTOK,		1,		0,
	"obj",		ROBJ,		3,		0,
	"cpr",		CDCRTK,		1,		0x10,
	"lib",		LIB,		3,		0,
#ifdef HITACHI
	"in0",		IN0,		2,		0,
	"slp",		DBTOK,		0,		0x76,
	"tst",		TSTTOK,		1,		0x64,
	"mlt",		MLTTOK,		1,		0,
#endif
	0,		0,		0,		0
};

TABLE	orlstp4[] = 
{
/*
	symbol		token		# of operands	code
*/
	"call",		CALLTK+CONBIT,	2,		0,
	"defl",		DEFLTK,		1,		0,
	"defb",		DEFBTK,		-1,		0,
	"byte",		DEFBTK,		-1,		0,
	"defw",		DEFWTK,		-1,		0,
	"word",		DEFWTK,		-1,		0,
	"defs",		DEFSTK,		1,		0,
	"base",		RADIXT,		1,		0,
	"defm",		DEFMTK,		3,		0,
	"deft",		DEFMTK,		3,		0x1,
	"defe",		DEFMTK,		3,		0x4,
	"defr",		DEFMTK,		3,		0x5,
	"halt",		SBTOK,		0,		0x76,
	"rlca",		SBTOK,		0,		0x7,
	"rrca",		SBTOK,		0,		0xf,
	"ldir",		DBTOK,		0,		0xb0,
	"lddr",		DBTOK,		0,		0xb8,
	"cpir",		DBTOK,		0,		0xb1,
	"cpdr",		DBTOK,		0,		0xb9,
	"reti",		DBTOK,		0,		0x4d,
	"retn",		DBTOK,		0,		0x45,
	"inir",		DBTOK,		0,		0xb2,
	"indr",		DBTOK,		0,		0xba,
	"outi",		DBTOK,		0,		0xa3,
	"otir",		DBTOK,		0,		0xb3,
	"outd",		DBTOK,		0,		0xab,
	"otdr",		DBTOK,		0,		0xbb,
	"djnz",		DJNZTK,		1,		0,
	"push",		PUSHTK,		1,		0xc5,
	"date",		DEFMTK,		3,		0x2,
	"time",		DEFMTK,		3,		0x3,
	"page",		ORGTOK,		1,		0x4,
	"ifnz",		CONDTK,		1,		IFNZERO,
	"else",		CONDTK,		0,		IFELSE,
	"endm",		MACROT,		0,		0x2,
	"mend",		MACROT,		0,		0x2,
	"save",		SAVETK,		1,		0,
	"rstr",		RSTRTK,		1,		0,
	"exit",		EXITOK,		1,		0,
	"endi",		ENDITK,		2,		0,
	"drop",		DROPTK,		2,		0,
	"apop",		APOPTK,		-1,		0,
	"movi",		MOVTOK,		3,		0xb0,
	"movd",		MOVTOK,		3,		0xb8,
	"cmpi",		CMPTOK,		3,		0xa0,
	"cmpd",		CMPTOK,		3,		0xa8,
	"link",		LINK,		3,		0,
	"fill",		FILLTK,		0,		0xff,
	"load",		XLOAD,		3,		0,
	"rlld",		RRRRSS,		2,		0x10,
	"rrld",		RRRRSS,		2,		0x18,
	"cseg",		ORGTOK,		1,		0x7,
	"aseg",		ORGTOK,		1,		0x5,
	"dseg",		ORGTOK,		1,		0x6,
	"name",		TKNAME,		3,		0,
#ifdef HITACHI
	"out0",		IN0,		2,		0,
	"otim",		DBTOK,		0,		0x83,
	"otdm",		DBTOK,		0,		0x8b,
#endif
	0,		0,		0,		0
};


TABLE	orlstp5[] = 
{
/*
	symbol		token		# of operands	code
*/
	"title",	TITTOK,		3,		0,
	"block",	DEFSTK,		1,		0,
	"eject",	EJETOK,		0,		0,
	"noend",	ENDTOK,		0,		0x3,
	"ifdef",	CONDTK,		1,		IFDEF,
	"ifund",	CONDTK,		1,		IFNDEF,
	"endif",	CONDTK,		0,		IFENDIF,
	"macro",	MACROT,		-1,		0x1,
	"print",	PRINT,		-1,		0,
	"patch",	PATCH,		2,		0,
	"psect",	ORGTOK,		1,		0x3,
	"isect",	ISECTK,		2,		0,
	"using",	USINGT,		2,		0,
	"ascii",	DEFMTK,		3,		0,
	"extrn",	EXTRNT,		-1,		0,
	"entry",	ENTRYT,		-1,		0,
	"radix",	RADIXT,		1,		0,
	"adisp",	PRINTV,		3,		0,
	"apush",	APUSHT,		-1,		0,
	"glink",	GLINK,		3,		0,
	"rlcld",	RRRRSS,		2,		0,
	"rrcld",	RRRRSS,		2,		0x8,
	"slald",	RRRRSS,		2,		0x20,
	"srald",	RRRRSS,		2,		0x28,
	"slold",	RRRRSS,		2,		0x30,
	"srlld",	RRRRSS,		2,		0x38,
	"resld",	SETLDT,		3,		0x80,
	"setld",	SETLDT,		3,		0xc0,
	"local",	LOCALT,		-1,		0,
#ifdef HITACHI
	"otimr",	DBTOK,		0,		0x93,
	"otdmr",	DBTOK,		0,		0x9b,
	"tstio",	TSTTOK,		1,		0x74,
#endif
	0,		0,		0,		0
};


TABLE orlstp6[] = 
{
/*
	symbol		token		# of operands	code
*/
	"header",	HEADER,		3,		0,
	"global",	GLOBTK,		-1,		0,
	"setloc",	ORGTOK,		1,		0x8,
	"resloc",	ORGTOK,		0,		0x2,
	"litorg",	LITORT,		1,		0,
	"maclib",	REFER,		1,		0,
	"nofill",	FILLTK,		0,		0,
	"encode",	ORGTOK,		1,		0x9,
	"noload",	YLOAD,		0,		0,
	"public",	ENTRYT,		-1,		0,
	"extern",	EXTRNT,		-1,		0,
	"includ",	INCLUD,		3,		0,
	"lnkset",	LNKSTK,		1,		0,
	0,		0,		0,		0
};


TABLE	orlstp7[] = 
{
/*
	symbol		token		# of operands	code
*/
	"include",	INCLUD,		3,		0,
	"heading",	HEADER,		3,		0,
	"version",	VERSN,		3,		0,
	0,		0,		0,		0
};

/*	File:	radix.c
 *
 *	Contains:	radix
 *
 *	This is the RADIX handler.
 */




#include "asm.h"




void grp38(token)
unsigned char token;
{
	char	b;

#if DEBUG
printf("group 38\n");
#endif


	b = odint1;
	plchg = 0;

	if (token == 0x90)
	{
		if (b > 17 || b < 2)
		{
			eror('S');
			return;
		}

		if (b == 2 || b == 8 || b == 10 || b == 16)
		{
			radix = b;

			if (b != 10)
				plchg = 1;
		}
		else
		{
			eror('S');
			return;
		}
	}
	else
		dnops();
}

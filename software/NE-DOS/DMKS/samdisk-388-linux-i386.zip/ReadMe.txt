SAMdisk
-------

Advanced floppy disk image utility for Windows, by Simon Owen.

http://simonowen.com/samdisk/

---

Zlib software copyright (c) 1995-2014 Jean-loup Gailly and Mark Adler.
Bzip2 software copyright (c) 1996-2014 julian@bzip.org
Flux stream processing by Keir Fraser, released as public domain.

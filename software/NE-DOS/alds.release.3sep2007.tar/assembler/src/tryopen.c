/*	File:	tryopen.c
 *
 *	Contains:	look, swap, strip, tryopen, cgenv
 *
 *	These routines will try to open a file. They will attempt to
 *	add an environment variable if requested, and will change
 *	case (upper/lower) if needed.
 */



#include "asm.h"
#include <string.h>
#define index strchr
#define rindex strrchr



static	FILE	*fp;




/*
	this routine will look at a filename and return a pointer to
	the name itself bypassing any path.
*/

unsigned char * look(pointer)
register unsigned char * pointer;
{
	register unsigned char	*pnt1;

	if((pnt1 = (unsigned char *)rindex(pointer, '/')))
		return(++pnt1);
	else
		return(pointer);
}



/*	This routine gets a pointer to the filename itself bypassing
	any path, then will reverse the case (upper/lower) of the
	filename.
*/

void swap(pointer)
register unsigned char	*pointer;
{
	pointer = look(pointer);

	while(*pointer)
	{
		if ((*pointer >= 'A' && *pointer <= 'Z') ||
		  (*pointer >= 'a' && *pointer <= 'z'))
			*pointer ^= ' ';

		++pointer;
	}
}




/*	This routine will get an environment variable for path
	name substitution.
*/

char *cgenv(pnt)
register char *pnt;
{
	register char	*ev;


	if ((ev = getenv(pnt)) == NULL)
	{
		swap(pnt);

		if ((ev = getenv(pnt)) == NULL)
			return(pnt);
	}

	(void) strcpy(pnt, ev);

#if DEBUG
printf("cgenv:*%s*\n",pnt);
#endif

	/*
	 * changed 3/10/83 rl so '/' is added ONLY if it's not supplied
	 */
	if (pnt[strlen(pnt)-1] != '/')
		(void) strcat(pnt, "/");

	return(&pnt[strlen(pnt)]);
}



/*	This routine will attempt to open a file. If successful, it
	will return the file pointer. If not, it will reverse the
	case (upper/lower) of the name (only, not path) and attempt
	the open again. If good, it will return the pointer, else
	return 0.  If an environment variable is found, it will be
	expanded if possible.
*/
FILE *tryopen(ptr)
register char *ptr;
{
	register char	*bp, *cp;
		 char	filename[100];

	bp = ptr;
	cp = filename;
	
	while(*bp)
	{
		if (*bp == ':')
		{
			*cp = 0;
			cp = cgenv(filename);
			
#if DEBUG
printf("tryopen:cgenv =*%s*\n",cp);
#endif
			
		}
		else if (*bp == '\'' || *bp <= ' ')
			break;
		else
			*cp++ = *bp;

		++bp;
	}

	*cp = 0;


#if DEBUG
printf("tryopen:*%s*\n",filename);
#endif
	if ((fp = fopen(filename, "r")) == NULL)
	{
		swap(filename);

#if DEBUG
printf("tryopen:*%s*\n",filename);
#endif
		if ((fp = fopen(filename, "r")) == NULL)
		{
			swap(filename);
			return(0);
		}
	}

	strcpy(ptr, filename);
	return(fp);
}





/*	search for an extension		*/
unsigned char *search(pnt)
register unsigned char	*pnt;
{
	pnt = look(pnt);

	if((pnt = (unsigned char *) index(pnt, '.')))
		return(pnt);
	else
		return(0);
}

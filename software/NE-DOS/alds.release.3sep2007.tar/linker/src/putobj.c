/*	File:	putobj.c
 *
 *	This routine will store a byte of code in the object buffer.
 */




#include "link.h"



extern	unsigned char	chksum;
extern	FILE		*objfile;
extern	unsigned int	lflag;
extern	unsigned char	objbuf[];
extern	unsigned int	ocount;
extern	unsigned int	adrefc[];
extern	unsigned char	mode;
extern	unsigned int	inclf;
extern	unsigned char	opnrec;
extern	unsigned char	passno;
extern	unsigned char	cmdflag;
extern	unsigned int	Orecord;

static	unsigned char	xcount;
unsigned char		saveflag;
unsigned int		adrsave;





objout(byte)
unsigned char	byte;
{
	if(lflag & LADIS)
		clsrec();

	if(!opnrec)
		openr();

	++adrefc[mode];
	objbuf[ocount++] = byte;

	if(++objbuf[0] == Orecord)
		clsrec();
}







/*	close an object record	*/
clsrec()
{
	unsigned char	count, i;


	if(passno == 2)
	{
		if(opnrec && objbuf[0])
		{
			xwrite(':');
			count = 0;
			chksum = 0;

			for(i = 0; i < 3; i++)
				puthex(objbuf[count++]);

			puthex(0);


			for(i = 0; i < objbuf[0]; i++)
				puthex(objbuf[count++]);

			puthex((~chksum) + 1);
			xwrite('\n');
		}
	}

	lflag &= ~LADIS;
	opnrec = 0;
	objbuf[0] = 0;
}



/*	open an object record	*/
openr()
{
	ocount = 0;
	objbuf[ocount++] = 0;
	objbuf[ocount++] = (adrefc[mode] >> 8) & BYTMSK;
	objbuf[ocount++] = adrefc[mode] & BYTMSK;
	opnrec = 1;
}




dskword(word)
unsigned int	word;
{
	puthex(word >> 8);
	puthex(word);
}


/*	write a byte with checksum	*/
puthex(byte)
unsigned char	byte;
{
	chksum += byte;
	xwrite(hexasc(byte >> 4));
	xwrite(hexasc(byte));
}




/*	write a byte to the disk file	*/
xwrite(byte)
unsigned char	byte;
{
	if(passno == 1)
		return;

	++xcount;

	if(byte == '\n')
		xcount = 0;

	if(xcount >= 80)
	{
		putc('\n', objfile);
		xcount = 0;
	}

	putc(byte, objfile);
}



/*	output the transfer address	*/
traout(address, flag)
unsigned short	address;
unsigned int	flag;
{
	if(cmdflag && address)
	{
		saveflag = 1;
		adrsave = address;
	}

	if(cmdflag && flag)
		return;

	if(!inclf)
	{
		clsrec();
		xwrite(':');
		chksum = 0;
		puthex(0);

		if(saveflag)
			dskword(adrsave);
		else
			dskword(address);

		puthex(1);
		puthex((~chksum) + 1);
		xwrite('\n');
	}
}

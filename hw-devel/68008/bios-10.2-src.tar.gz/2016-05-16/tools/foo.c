/* foo.c */
#include <stdio.h>
#include "mytypes.h"



void main(void)
{
	printf("int32=%d\n", (int)sizeof(int32));
}


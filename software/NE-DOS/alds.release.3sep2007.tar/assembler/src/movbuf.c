/*	File:	movbuf.c
 *
 *	Contains:	movbuf, clrbuf, str
 *
 *	This routine will move a quoted text string from 'pnt1' to 'pnt2'
 *	It will watch for, and take care of double quotes within a string.
 *	The entry parameter 'flag' determines how we interpret the
 *	characters of 'from'. If the flag is positive, the characters are
 *	treated as ascii text. If the flag is negative, the characters
 *	are treated as binary values and not checked at all.
 *		Flag	Means
 *		 0	Interpret '' to single quote.
 *		 1	Same as 0, but interpret '~' to 0x0d, '^' to bit 7 on.
 *		 2	Same as 1, but additionally ENCODE the chars.
 *		-1	Don't interpret anything. Output AS IS.
 *		-2	Same as -1, but no length, terminate on NULL.
 */



#include "asm.h"



unsigned char *movbuf(from, to, lenx, flag)
register unsigned char *from, *to;
register int lenx;
int flag;
{
	short	point;
	char	c;
	char	orit;
	
#if DEBUG
printf("movbuf:lenx=%d  flag=%d\n",lenx,flag);
#endif

	orit = 0;
	point = 0;


	if (flag == -2)
	{
		while(*from)
			*to++ = *from++;

		*to = 0;
		return(to);
	}



	/*
	 * if we're pointing to the 1st single quote, skip it
	 */
	if (flag >= 0 && *from == SQUOTE)
		++from;

	/*
	 * move the line
	 */
	while(lenx--)
	{
		c = from[point++];
		
		if (flag < 0)
			*to++ = c;
		else
		{
			if (c == SQUOTE && from[point] == SQUOTE)
				++point;
			else if (flag)
			{
				if (c == '~')
					c = CRLF;
				else if (c == '^')
				{
					orit = (orit) ? 0 : 0x80;
					c = from[point++];
				}
			}
			
			if (flag)
			{
				if (flag == 2 && c != CRLF)
						c ^= encode;

				c |= orit;
			}

			*to++ = c;
		}
	}

	return(to);
}


/*.
*************************************************************************
*									*
*	clrbuf								*
*	------								*
*									*
*	clear a buffer							*
*									*
*	int clrbuf(pnt,length)						*
*									*
*	<pnt> register char *pnt					*
*		pointer to buffer					*
*									*
*	<length> register int length					*
*		size of buffer						*
*									*
*************************************************************************
*/
void clrbuf(pnt,length)
register char *pnt;
register int length;
{
	while(length--)
		*pnt++ = 0x00;
}


/*.
*************************************************************************
*									*
*	str								*
*	---								*
*									*
*	return the length of an ascii text string			*
*									*
*									*
*									*
*************************************************************************
*/
int str(pnt)
register char *pnt;
{
	register int	count;

	count = 0;

	/*
	 * if we're pointing to the 1st quote, skip it
	 */
	if (*pnt == SQUOTE)
		++pnt;

	/*
	 * get the count of the line
	 */
	while (*pnt || *pnt == CRLF)
	{
	
#if DEBUG
printf("str: *%c*\n",*pnt);
#endif
	
		if (pnt[0] == SQUOTE && pnt[1] == SQUOTE)
		{
			count++;
			pnt += 2;
			
#if DEBUG
printf("str: found two single quotes\n");
#endif
			
		}
		else if (*pnt == SQUOTE)
		{

#if DEBUG
printf("str: found ending quote\n");
#endif

			break;
		}
		else if (*pnt == '^')
		{
			pnt++;
			
#if DEBUG
printf("str: found '^'\n");
#endif

		}
		else
		{
			count++;
			pnt++;
			
#if DEBUG
printf("str: bump count\n");
#endif
			
		}
	}

	return(count);
}

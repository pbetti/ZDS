This folder contains a selection of projects for use with SCWorkshop.

It is recommended that you store your own projects in a different folder,
such as SCWorkshop\MyProjects

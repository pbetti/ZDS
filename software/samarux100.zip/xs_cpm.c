/*	xs_rm.c

	CPM for Samarux.

	Execute CP/M commands.

	Copyright (c) 2007 - 2015 Miguel I. Garcia Lopez.

	This program is free software; you can redistribute it and/or modify it
	under the terms of the GNU General Public License as published by the
	Free Software Foundation; either version 2, or (at your option) any
	later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

	Usage:

	cpm command [arg ...]

	Options:

	None.

	Examples:

	cpm type hello.txt

	Changes:

	04 Jan 2015 : 1.00 : 1st version.
	05 Jan 2015 : 1.01 : Uses temporary drive in CP/M 3.
	08 Jan 2015 : 1.02 : Adapted to shell changes.
	16 Feb 2015 : 1.03 : Changed return command.
	23 Feb 2015 : 1.04 : Changed return command again.
	                     Save SamaruX status, to be restored when restart.

	Notes:

	In CP/M 3, we could use the BDOS fn. 47 - Chain to program, but
	for compatibility with CP/M 2, we use the $$$.SUB CCP feature.
*/

CpmMain(argc, argv)
int argc, argv[];
{
	int i;
	char *p, *bf, *sam, *sub, pb[2];
	FILE *fp;

	/* Check arguments */

	if(argc == 1)
		return ErrorPars();

	/* Buffer */

	if((bf = malloc(256)) == NULL)
		return ErrorMem();

	/* Samarux return command */

	sam = "sx -r";

	/* Submit file name */

	sub = "?:$$$.SUB"; *sub = 'A' + sv_drive;

	/* For CP/M 3, set temporary drive if any */

	if(sv_cpmver == 0x31)
	{
		pb[0] = 0x50; pb[1] = 0;

		if((i = bdos_a(0x31, pb)))
			*sub = 'A' + i - 1;
	}
		
	/* First record: Samarux return command */

	strcpy(bf + 1, sam); *bf = strlen(bf + 1);

	/* Second record: CP/M command line */

	p = bf + 129; *p = 0;

	for(i = 1; i < argc; ++i)
	{
		strcat(p, argv[i]);

		if(i != argc - 1)
			strcat(p, " ");
	}

	bf[128] = strlen(p);

	/* Make $$$.SUB file */

	if((fp = fopen(sub, "wb")) != NULL)
	{
		if(fwrite(bf, 256, 1, fp) == 1)
		{
			if(!fclose(fp))
			{
				/* Save SamaruX status and exit to CP/M */

				if(!SaveStatus())
					exit();
			}
		}
	}

	/* Free buffer */

	free(bf);

	/* Failure */

	return Error("Can't execute");
}


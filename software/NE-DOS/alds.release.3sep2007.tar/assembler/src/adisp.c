/*	File:	adisp.c
 *
 *	Contains:	adisp
 *
 *	This is the ADISP pseudo-op handler.
 */
 
 
 

#include "asm.h"


#define TBUFFSIZE	10
static unsigned char	tbuff[TBUFFSIZE];

static	char	revvid[] =
{
	0x1b, 0x30, 0
};

static	char	norvid[] =
{
	0x1b, 0x39, 0
};



void adisp()
{
	register SYM	*symptr;
	register char	*bp;
	register unsigned char	*fp;
	char	buff[100];

	dont = 1;

	if (refflg || false_condit)
		return;

	if (passno == 2)
	{
		fp = skipsp(linpnt);

		while(*fp)
		{
			if (*fp == '~')
			{
				(void) gsym(skipsp(++fp), labbuf);

				if (symptr = loc_symbol(labbuf))
				{
					ascdno = 0;

					if (errbuf[0] != SPACE)
					{
						--errcnt;
						errbuf[0] = SPACE;
					}

					reff_symbol(symptr,1);
					dont = 0;
				}

				return;
			}

			++fp;
		}

		return;
	}

#if DEBUG
printf("adisp\n");
#endif


	if (logfile)
		printl("Adisp:\t");

	linpnt = skipsp(linpnt);

	if (*linpnt == SQUOTE)
		++linpnt;
	else
	{
		eror('S');
		return;
	}

	for(;;)
	{
		if(*linpnt == SQUOTE)
		{
			if(linpnt[1] == SQUOTE)
			{
				printl("%c", *linpnt++);
				++linpnt;
				continue;
			}
			else
				break;
		}

		if (term(linpnt))
			break;

		if (*linpnt == '^')
		{
			++linpnt;

			fp = skipsp(linpnt);
			linpnt = fp;
			bp = buff;

			while (*linpnt != SQUOTE && term(linpnt) == 0)
				*bp++ = *linpnt++;

			*bp = 0;
			eval(buff);

			if (*errbuf != SPACE)
			{
				printl(revvid);

				if (*errbuf == 'U')
					printl("UNDEFINED");
				else
					printl("Expression Error");

				printl(norvid);
				printl("\n");
				return;
			}

			(void) sprintf(buff, "%04x", (unsigned short) evalue);
			bp = buff;

			while(*bp)
			{
				*bp = atoupper(*bp);
				++bp;
			}

			printl("%s\n", buff);
			return;
		}

		if (*linpnt == '~')
		{
			(void) gsym(skipsp(++linpnt), labbuf);
			(void) fgets(tbuff,TBUFFSIZE-1,stdin);

			if (tbuff[0] == 0)
				printl("\nWARNING: No answer supplied to: %s\n", skipsp(minbuf));
			else
			{
				linpnt = tbuff;

				if (dolog)
					printl("\n");
			}

			ortkbf[0] = DEFLTK;
			labflg = 0;
			(void) proc_symbol(DEFLTK,NULL);
			return;
		}

		printl("%c", *linpnt++);
	}

	printl("\n");
}

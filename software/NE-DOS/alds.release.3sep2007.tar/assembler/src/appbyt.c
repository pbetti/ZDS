#include "asm.h"



/*	append a word to object code buffer	*/
void appwd(value)
short value;
{
	asscod[ascdno++] = (char) value;
	asscod[ascdno++] = (char) (value >> 8);
}




/*	adjust address reference counter (pc)	*/
void adjarc()
{
	if (false_condit || adjflg)
		return;

#if DEBUG
printf("adjarc: %x\n", ascdno);
#endif

	adjflg = 1;
	adrefc[mode] += ascdno;

	if(passno == 2 && (adrefc[mode] & (unsigned) 0xff0000))
	{
		eror('o');
		printl("Warning: address wrap on (%d)/%d\n", filenum, sline - 1);
	}
}

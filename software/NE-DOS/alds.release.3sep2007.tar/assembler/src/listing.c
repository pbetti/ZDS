/*	File:	lstln.c
 *
 *	Contains:	lstln;
 *
 *	This file outputs the entire line (one) to the listing device.
 */



#include "asm.h"

#define	LINE1	22
#define	LINE2	26

extern	int	pass1;
extern	int	xrefyes;
extern	int	atruncate;

int	lpoint;		/* counter into listing line buff */
int	col;		/* column indicator */
char	lst_rel_tick = ' ';

char	ffchar[2] = { 0x00, 0x00 };
static	int	print_func;

static	char	phead[] =
{"C  Z80/Z180 Assembler  Version 3(1)\tPage: %-3d\tDate: %s"};

static	char	sphead[] =
{"C  Z80/Z180 Assembler  Version 3(1)\tPage: %-3d"};

static	char	module[] =
{"(%d) Assembly listing of: %s\n"};

static unsigned char	symmsg[] =
{"Cross Reference Symbol Table"};

static char	ohead[] =
{"E Addr\t  Obj\t       Fl  Ln #\t\tSource Line"};

static char	shead[] =
{"Label\t\tValue\tRef Line #"};

static	unsigned char	*ln4 = hedbuf;		/* pointer to which line 4 */
static	char	*ln5 = ohead;		/* pointer to which line 5 */

void change()
{
	ln4 = symmsg;
	ln5 = shead;
}



/*.
*************************************************************************
*									*
*	lstln								*
*	-----								*
*									*
*									*
*									*
*									*
*************************************************************************
*/
void lstln()
{
	register unsigned char	*ptr;
	register int	count,cnt1;
		 char	squote;
		 unsigned char	codbuf[18];

#if DEBUG
printf("lstln\n");
#endif

	if (false_condit)
	{
		ascdno = 0;

		if (errbuf[0] != SPACE)
		{
			--errcnt;
			errbuf[0] = SPACE;
		}

		if (!print_con)
			return;
	}

	if (!pass1 && passno == 1)
		return;

	if (errbuf[0] == SPACE)
		if (dont || lstoff || !lisfile)
			return;

	if (xrefyes)
		return;

	if (!ascdno && is_off(AFSYMB | AFORG | AFEQDL))
	{
		squote = ' ';

		if (conflg && print_con)
			squote = 'c';

		(void) sprintf(lline,"%c\t\t\t%c ",errbuf[0],squote);
	}
	else
	{
		(void) sprintf(lline,"%c %04.4X%c\t",errbuf[0],addisr,lst_rel_tick);
		col = 8;
		lpoint = 8;
		count = ascdno;
		
		if (count > LBYTES && print_short && lstcnt == LBYTES)
			count = LBYTES;

		cnt1 = 0;
		ptr = asscod;

		while (count--)
		{
			if (cnt1 == lstcnt)
			{
				lline[lpoint] = 0;
				print();
				lpoint = 0;
				lline[lpoint++] = '\t';
				col = 8;
				cnt1 = 0;
			}

			++cnt1;
			lline[lpoint++] = hexasc(*ptr >> 4);
			lline[lpoint++] = hexasc(*ptr++);
			col += 2;
		}

		lline[lpoint] = 0;

		while ((LINE1 - col) > 8)
		{
			putx(1,'\t');
			col += 8 - (col % 8);
		}

		putx(LINE1 - col, SPACE);
		

		(void) strcpy(codbuf,"   ");
		ptr = codbuf;

		if (refpno)
			*ptr++ = '-';

		if (mathfg & MFENT && !bglob)
			*ptr++ = 'p';

		if(mathfg & MFDSEG)
			*ptr++ = 'd';
		else if (mathfg & MFEXT)
		{
			if (ps && psave != pdef)
				*ptr++ = 'x';
			else if (!ps)
				*ptr++ = 'x';

			psave = pdef;
		}
			
		if (mathfg & MFRLEM)
			*ptr++ = 'r';
		
		if (bglob)
			*ptr++ = 'g';

		if ((lglob & SYMDFL) == SYMGBL)
			*ptr++ = '+';

		if (conflg && print_con)
			codbuf[2] = 'c';

		codbuf[3] = ' ';
		(void) strncat(lline,codbuf,4);
	}

	(void) strcat(lline, numbbb);
	(void) strcat(lline, minbuf);
	
	if (lisfile)
		print();

	if (errbuf[0] != SPACE)
	{
		eprintl(lline);
		printl("\n");
	}

	dont = 1;
}


/*.
*************************************************************************
*									*
*	putx								*
*	----								*
*									*
*	put a number of bytes into the listing buffer			*
*									*
*									*
*									*
*************************************************************************
*/
void putx(count, byte)
register int count;
char byte;
{
	if (count > 0)
 	{
 		col += count;

		while(count--)
			lline[lpoint++] = byte;

		lline[lpoint] = 0;
	}
}


/*.
*************************************************************************
*									*
*	print								*
*	-----								*
*									*
*									*
*									*
*									*
*************************************************************************
*/
void print()
{
	register int	c;
	register unsigned char	*pnt;


	if(print_func == 0)
	{
		ffeed();
		ffchar[0] = FORMFD;
		print_func = 1;
	}

	if(atruncate)
	{
		c = 0;
		pnt = lline;

		while(*pnt)
		{
			if(*pnt == '\t')
				c = (c + 8) & ~7;
			else
				++c;

			if(c > 78)
				break;

			++pnt;
		}

		*pnt = 0;
	}

	fprintf(lisfile, "%s", lline);
	lfeed();
}



/*.
*************************************************************************
*									*
*	lfeed								*
*	-----								*
*									*
*	output a line feed to listing device				*
*									*
*									*
*									*
*************************************************************************
*/
void lfeed()
{
	if (lstoff)
		return;

	(void) fprintf(lisfile,"\n");
	++line;

	if (line < (PLINES - 1))
		return;
	
	ffeed();
}


/*.
*************************************************************************
*									*
*	ffeed								*
*	-----								*
*									*
*	output a form feed to listing device				*
*									*
*									*
*									*
*************************************************************************
*/
void ffeed()
{
	if (lstoff || xrefyes || passno == 1)
	{
		line = 0;
		return;
	}

	(void) fprintf(lisfile,"%s",ffchar);
	
	/* line 1 */
	if (atruncate)
		(void) fprintf(lisfile, sphead, page++);
	else
		(void) fprintf(lisfile, phead, page++, dateb);

	if (incpnt && *incpnt)
		(void) fprintf(lisfile, "\tInclude: %s",incpnt);

	(void) fprintf(lisfile,"\n");

	/* line 2 */
	(void) fprintf(lisfile, module, file_no, savebuf);

	/* line 3 */
	(void) fprintf(lisfile,"%s\n",titbuf);

	/* line 4 */
	(void) fprintf(lisfile,"%s\n",ln4);

	/* line 5 */
	(void) fprintf(lisfile,"%s\n\n\n",ln5);

	line = 0;
}



/*.
*************************************************************************
*									*
*	ejecit								*
*	------								*
*									*
*	handler for EJECT pseudo-op					*
*									*
*									*
*									*
*************************************************************************
*/
void ejecit()
{
	if (passno == 1 || !lisfile)
		return;

	if(line)
		ffeed();

	dont = 1;
}


/*.
*************************************************************************
*									*
*	xxobj								*
*	-----								*
*									*
*	display one line of object					*
*									*
*	xxobj()								*
*									*
*	returns no value						*
*									*
*************************************************************************
*/
void xxobj()
{
	register int i;
	register unsigned char *cptr;

	if (passno == 1 || !lisfile || xrefyes)
		return;

	(void) fprintf(lisfile, "%c %04.4X%c\t", errbuf[0], addisr, lst_rel_tick);
	i = ascdno;
	cptr = asscod;

	while(i--)
		(void) fprintf(lisfile,"%02.2X",*cptr++);

	lfeed();
	
	if (errbuf[0] != SPACE)
	{
		(void) sprintf(lline,"%c%s",errbuf[0],&lline[1]);
		eprintl(lline);
		printl("\n");
		errbuf[0] = SPACE;
	}
}

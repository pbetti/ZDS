/*	File:	pass.c
 *
 *	Contains:	passx, doasm
 *
 *	This is the main control loop for each pass of the assembler.
 */




#include "asm.h"
#include "imd.h"
extern	int	pass1;
extern	char nrands;
extern	MAC	*mp_ptr;


void passx()
{
#if DEBUG
printf("pass\n");
#endif

	/* init the assembler for a pass */
	initp();

	while(getline() != EOF)
	{
		/* assemble one line */
		doasm(0);


		if (is_on(AFENDS))
			break;
	}

	if (is_off(AFENDS))
	{
		condi1 = 0;
		false_condit = 0;
		ifcnt = 0;
		eror('E');
		strcpy(numbbb,"99999\t");
		strcpy(minbuf, "\tEND");
		doasm(1);
	}
}







/*.
*************************************************************************
*									*
*									*
*	assemble 1 line of code						*
*									*
*									*
*									*
*************************************************************************
*/
void doasm(flag)
register int flag;
{
	
	IMD		imd;
	register IMD	*ip;
	char	c;
	
#if DEBUG
printf("doasm\n");
#endif

	/*
	 * init the assembler for a line
	 */
	initl(flag);
	ip = &imd;

	if (rlist)
		printl("%s%s\n", numbbb, minbuf);

	/*
	 * process label is present
	 */
	if ((c = get_label(minbuf)) == MORE)
	{
		/*
		 *	decode opcode
		 */
		if (passno == 1)
		{
			getor(linpnt);

			ip->i_op_start[0] = (char *) linpnt;
		
			/*
			 *	if there is a label, then process it
			 */
			if (*labbuf != 0)
			{
				c = ortkbf[0];
				/*
				 *	label on a macro definition goes with the macro, do not process
				 *	can not have a label on 'global' or 'org'
				 */
				if (c != GLOBTK && c != ORGTOK && c != MACROT)
					ip->i_SYM = proc_symbol(c,NULL);
			}
			
			if (nrands == 1 || nrands == 2)
			{
				ip->i_op_start[1] = (char *) getopd(linpnt, &opbyt1, &odint1, 1);
				ip->i_opbyt1 = opbyt1;
				ip->i_odint1 = odint1;
				ip->i_errbuf[0] = errbuf[0];

				if (mathfg & MFEXT)
					ip->i_errbuf[0] = 'X';
				
				if (ip->i_op_start[1] != EMPTY)
				{
					(void) getopd(linpnt, &opbyt2, &odint2, 2);
					ip->i_opbyt2 = opbyt2;
					ip->i_odint2 = odint2;
					ip->i_errbuf[1] = errbuf[0];

					if (mathfg & MFEXT && ip->i_errbuf[0] != 'X')
						ip->i_errbuf[1] = 'X';

					if (*ip->i_op_start[1] == LITORG)
						ip->i_errbuf[1] = 'L';
				}
				else
				{
					ip->i_opbyt2 = 0;
					ip->i_odint2 = 0;
				}
			}

			ip->i_ortkbf[0] = ortkbf[0];
			ip->i_ortkbf[1] = ortkbf[1];
			ip->i_nrands = nrands;
			ip->i_mathfg = mathfg;
			ip->i_hilow = hilow;
			ip->i_hladdr = hladdr;
			ip->i_mp_ptr = mp_ptr;

			if (is_on(AFUSPR))
			{
				ip->i_errbuf[0] = 'X';
				ip->i_errbuf[1] = 'X';
			}

			if (!refflg)
				(void) fwrite(ip,ISIZE,1,imdfile);
			
			if (*ortkbf == 0xff)
				macro();
			else
				ptok();
		}
		else
		{
			(void) fread(ip,ISIZE,1,imdfile);
			ortkbf[0] = ip->i_ortkbf[0];
			ortkbf[1] = ip->i_ortkbf[1];
			nrands = ip->i_nrands;
			mathfg = ip->i_mathfg;
			hilow = ip->i_hilow;
			hladdr = ip->i_hladdr;
			linpnt = (unsigned char *) ip->i_op_start[0];
			mp_ptr = ip->i_mp_ptr;
			opbyt1 = ip->i_opbyt1;
			opbyt2 = ip->i_opbyt2;
			odint1 = ip->i_odint1;
			odint2 = ip->i_odint2;
			
			/*
			 *	if there is a label, then process it
			 */
			if (*labbuf != 0)
			{
				c = ortkbf[0];
				/*
				 *	label on a macro definition goes with the macro, do not process
				 *	can not have a label on 'global' or 'org'
				 */
				if (c != GLOBTK && c != ORGTOK && c != MACROT)
					(void) proc_symbol(c,ip->i_SYM);
			}

			if (nrands == 1 || nrands == 2)
			{
				if (ip->i_errbuf[0] != SPACE)
					(void) getopd(linpnt, &opbyt1, &odint1, 1);
				
				if (ip->i_errbuf[1] != SPACE && ip->i_op_start[1] != EMPTY)
					(void) getopd(ip->i_op_start[1], &opbyt2, &odint2, 2);
			}
			
			if (hilow & (O4MSB | O4LSB))
				turn_on(AFHILO);
			
			if (*ortkbf == 0xff)
				macro();
			else
				ptok();
		}

	}
	else if (c == DUMMY)
	{
		lstln();
		return;
	}
	else
	{
		if (passno == 1)
		{
			ip->i_SYM = proc_symbol(0,NULL);
			
			if (!refflg)
				(void) fwrite(ip,ISIZE,1,imdfile);
		}
		else
		{
			(void) fread(ip,ISIZE,1,imdfile);
			(void) proc_symbol(0,ip->i_SYM);
		}
	}


	/* if in ISECT mode, and we produced code, error */
	if (is_on(AFISEC) && ascdno)
	{
		ascdno = 0;
		eror('S');
	}


	if (false_condit)
		ascdno = 0;

	if (passno == 1)
		lstln();
	else
	{
		proces();
		lstln();

		if (objfile)
			putobj();
	}
}

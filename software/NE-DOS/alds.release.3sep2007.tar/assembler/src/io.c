/*	File:	io.c
 *
 *
 *
 */



#include "asm.h"




/* create a file
 *
 * return 0 if creation error
 */

FILE *xcreate(name)
register char *name;
{
        register char	*pnt;
		 char	xobuff[100];

	pnt = xobuff;

	while(name && *name)
		*pnt++ = atolower(*name++);

	*pnt = 0;
	return(fopen(xobuff, "w+")); /* will create a file if necessary*/
}



/* ret the current date and time */

#define	XTIME	struct tm

#ifdef M68000
long	ITIME = 0;
#else /*M68000*/
time_t	ITIME = 0;
#endif /*M68000*/
#ifdef OLDDATE
static	 char	*xmod[] =
{
	"Jan.",
	"Feb.",
	"March",
	"April",
	"May",
	"June",
	"July",
	"Aug.",
	"Sept.",
	"Oct.",
	"Nov.",
	"Dec."
};
#else /*OLDDATE*/
static	 char	*xmod[] =
{
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
};
#endif /*OLDDATE*/




void gettime()
{
	register XTIME	*tp;
	register char	*xp;


	(void) time(&ITIME);
	tp = localtime(&ITIME);
	xp = xmod[tp->tm_mon];
#ifdef OLDDATE
	(void) sprintf(dateb,"%s %d, %04d",xp,tp->tm_mday,tp->tm_year+1900);
#else /*OLDDATE*/
	(void) sprintf(dateb,"%02d-%s-%04d",tp->tm_mday,xp,tp->tm_year+1900);
#endif /*OLDDATE*/
	(void) sprintf(timeb, "%d:%02d:%02d", tp->tm_hour, tp->tm_min, tp->tm_sec);
}

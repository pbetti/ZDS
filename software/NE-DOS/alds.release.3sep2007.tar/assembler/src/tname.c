/*	File:	tname.c
 *
 *	Contains:	tname
 *
 *	This is the NAME pseudo-op handler.
 */




#include "asm.h"





void tname()
{
	(void) gsym(skipsp(linpnt), symbuf);

	if (symbuf[0])
	{
		(void) strcpy(pbuffr, symbuf);
		symbuf[6] = 0;
	}
}

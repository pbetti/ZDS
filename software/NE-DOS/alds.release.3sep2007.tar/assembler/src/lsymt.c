/*	File:	lsymt.c
 *
 *	Contains:	lsymt, newline, dspname, sfind, getsym, rsym
 *
 *	This routine will output the cross reference symbol table at
 *	the end of the assembly listing.
 */




#include "asm.h"


extern	char	xrefno;
extern	int	didinclude;
extern	int	prtyes;
extern	int	mperl;
extern	int	sperl;

static	short	last_file_no = -1;
static	short	lastline = -1;	/* last line numbered referenced */


void lsymt()
{
	register SYM	*sp;
	register REFF	*rp;
	register MAC	*mp;
  		 char	count, leng;


#if DEBUG
printf("list symbols\n");
#endif

	if (!lisfile)
		return;

	ffeed();
	fprintf(lisfile,"Macros:\t");
	count = mperl;
	mp = macbeg;

	while(mp)
	{
		(void) fprintf(lisfile,"%s\t",mp->mx_name);

		if (!(--count))
		{
			lfeed();
 			(void) fprintf(lisfile,"\t");
			count = mperl;
		}

		mp = mp->mx_right;
	}
	
	lfeed();
	lfeed();
	lfeed();
	(void) fprintf(lisfile,"Symbols:");
	lfeed();
	symcnt = 1;
	sp = symbeg;
	
	if (sp == NULL)
		return;

	do {
#if DEBUG
printf("looking: %s\n", sp->s_name);
#endif
		lastline = -1;
		
#if DEBUG
printf("lsymt: prtyes = %d  sp->s_flag2 = %d\n",prtyes,sp->s_flag2 & SLOCAL);
#endif

		if (prtyes || (sp->s_flag2 & SLOCAL) == 0)
		{
			if (sp->ref_beg)
			{
				rp = sp->ref_beg;

				leng = 0;

				if (sp->s_flag2 & SYMLOC)
				{
					(void) fprintf(lisfile,"..");
					leng = 2;
				}
				else if (sp->s_flag2 & MACLOC)
				{
					(void) fprintf(lisfile,"!");
					leng = 1;
				}


				(void) fprintf(lisfile,"%s",sp->s_name);
				
#if DEBUG
printf("list with refs: %s\n", sp->s_name);
#endif

				if (len(sp->s_name) + leng < 8)
					(void) fprintf(lisfile,"\t");
					
				(void) fprintf(lisfile,"\t%04.4X\t",sp->s_value & 0xffff);
				count = sperl;

				do {
					if (lastline != rp->r_line || last_file_no != rp->r_file_no)
					{
						lastline = rp->r_line;
						last_file_no = rp->r_file_no;

						if(didinclude)
							(void) fprintf(lisfile,"%2d/%-7d", rp->r_file_no, rp->r_line);
						else
							(void) fprintf(lisfile,"   %-7d", rp->r_line);

						if (!(--count))
						{
							count = sperl;
							lfeed();
							(void) fprintf(lisfile,"\t\t\t");
						}
					}

				} while (rp = rp->r_link);

				lfeed();
			}
			else if (prtyes || (sp->s_flag1 & (SYMREF | SYMGBL | SYMDFL)) == 0)
			{
				(void) fprintf(lisfile,"%s",sp->s_name);

				if (len(sp->s_name) < 8)
					(void) fprintf(lisfile,"\t");
					
				(void) fprintf(lisfile,"\t%04.4X\t",sp->s_value & 0xffff);
				lfeed();
				
#if DEBUG
printf("list without refs: %s\n", sp->s_name);
#endif

			}
		}

		++symcnt;

	} while (sp = sp->rightptr);

  	(void) fprintf(lisfile,"\n");
}


/*.
*************************************************************************
*									*
*									*
*									*
*									*
*									*
*************************************************************************
*/
void reff_symbol(fp,flag)
register SYM *fp;
int flag;
{
	register REFF	*rptr, *tmp;

	if (xrefno || (passno == 2 && !flag))
		return;
	
	rptr = (REFF *) xalloc(RSIZE);

	if (flag == 1)
		rptr->r_line = (short) -(sline - 1);
	else
		rptr->r_line = sline - 1;

	rptr->r_file_no = file_no;
	rptr->r_link = 0;
	
	if (fp->ref_end)
	{
		tmp = fp->ref_end;
		tmp->r_link = rptr;
	}

	fp->ref_end = rptr;
					
	if (fp->ref_beg == 0)
		fp->ref_beg = rptr;
}

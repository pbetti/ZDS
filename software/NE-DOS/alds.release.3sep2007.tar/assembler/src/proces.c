/*	File:	proces.c
 *
 *	Contains:	proces, p1proc
 *
 *	This routine is envoked at the end of each line of source code. It
 *	examines the various assembler flags that were set/reset during the
 *	process of that line, and sets the approiate flags for the object
 *	code routines to output it's code either relocatable or absolute.
 */



#include "asm.h"

extern	char	lst_rel_tick;



void proces()
{

#if DEBUG
printf("proces\n");
#endif


	o4cnt = 3;
	mathfg &= MFRLOF;

	if (is_off(AFASEG) && (mathfg & MFJRDJ) == 0)
	{
		lst_rel_tick = '\'';

		if (ascdno && mathfg & MFRLEX)
			hilow |= O4OBJ;

		if(is_on(AFDSEG))
			hilow |= O4DSEG;

		if (mathfg & MFEXT)
		{
			hilow |= O4EXT;
			o4cnt += slenth;
		}

		if (is_on(AFENTS))
		{
			if(mode == DSEG)
				hilow |= O4DSEG;

			mathfg |= MFENT;
			hilow |= O4ENT;

			if (is_on(AFABSL))
				hilow |= O4ABS;

			o4cnt += (slenth + 2);
		}

		if (ascdno && mathfg & MFRLEM)
			hilow |= O4OBJR;

		if (mathfg & MFO4HD || mathfg & MFSYRL || outchg == O7H)
			turn_on(AFO4HD);
	}
}


/*.
*************************************************************************
*									*
*									*
*	process psects and flags on pass 1				*
*									*
*									*
*									*
*************************************************************************
*/
void p1proc()
{
	register char	b;

#if DEBUG
printf("p1proc\n");
#endif

	if (passno == 2)
		return;

	b = 0;

	if (mathfg & MFEXT)
		b |= O6EXT;
	
	if (is_on(AFLINK))
		b |= O6LNK;
	
	if (is_off(AFASEG))
		b |= O6REL;

	ptable[pdef] |= b;
}

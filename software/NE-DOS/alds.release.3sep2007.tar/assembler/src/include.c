/*	File:	include.c
 *
 *	Contains:	refer, include
 *
 *	This is the REF and INCLUDE file handlers.
 */





#include "asm.h"



int	didinclude;


/*	reference a file	*/
void refer()
{
	register int	i;
		 short	temp2, temp3;
		 int	temp[SEGMENTS];

#if DEBUG
printf("ref/");
#endif

	if (passno == 2 || refflg)
		return;

	refflg = 1;

	for(i = 0; i < SEGMENTS; i++)
	{
		temp[i] = adrefc[i];
		adrefc[i] = 0;
	}

	temp2 = addisr;
	temp3 = offset;
	addisr = 0;
	offset = 0;
	includ(1);

	for(i = 0; i < SEGMENTS; i++)
		adrefc[i] = temp[i];

	addisr = temp2;
	offset = temp3;
	refflg = 0;
}



void incl()
{
	++didinclude;
	includ(0);
}




/*.
*************************************************************************
*									*
*	include								*
*	-------								*
*									*
*	include a file							*
*									*
*									*
*									*
*************************************************************************
*/
void includ(flag)
char flag;
{
	register FILE	*tfile, *sfile;
	register int	ln, old_file_no, old_sline;
	register unsigned char	*tp;
		 unsigned char	txname[70];


#if DEBUG
printf("include %s\n", linpnt);
#endif

	if (false_condit)
		return;
	
	if (inccnt == INCLEV)
	{
		if (logfile)
			printl("Include Nesting Exceeded..\n");

		eror('O');
		return;
	}
	
#if DEBUG
printf("include:name *%s*\n",linpnt);
#endif

	tp = skipsp(linpnt);
	
#if DEBUG
printf("include:name *%s*\n",linpnt);
#endif

	if ((ln = str(tp)) == 0)
	{
		dnops();
		return;
	}
	
#if DEBUG
printf("include:name size = %d\n",ln);
#endif

	tp = movbuf(tp, txname, ln, 0);
	*tp = 0;
	
#if DEBUG
printf("include:*%s*\n",txname);
#endif

	if (search(txname) == 0)
	{
		tp = look(txname);

		if (*tp >= 'A' && *tp <= 'Z')
			(void) strcat(tp, ".SRC");
		else
			(void) strcat(tp, ".src");
	}
	
#if DEBUG
printf("include:*%s*\n",txname);
#endif

	if ((sfile = tryopen(txname)) == 0)
	{
		printl("Can't include: %s\n", txname);
		xdone(1);
	}

	tp = incpnt;
	incpnt = txname;

	if (passno == 1 || dolog)
	{
		printl(flag ? "REF:\t%s" : "INCLUD:\t%s", incpnt);

		if (dolog)
		{
			gettime();
			printl(" at: %s", timeb);
		}

		printl("\n");
	}


	++inccnt;
	old_file_no = file_no;
	file_no = ++filenum;
	old_sline = sline;
	sline = 1;
	lstln();
	tfile = infile;
	infile = sfile;
	
#if DEBUG
printf("include:infile = %d\n",infile);
#endif

	while(getline() != EOF)
		doasm(0);

	turn_off(AFENDS);
	(void) fclose(infile);
	
	file_no = old_file_no;
	sline = old_sline;
	infile = tfile;
	
#if DEBUG
printf("include: infile = %d\n",infile);
#endif
	
	incpnt = tp;
	--inccnt;
	dont = 1;
}

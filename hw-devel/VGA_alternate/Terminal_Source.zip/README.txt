This source will compile correctly with Microchip MPLAB X IDE V5.25 and XC32 V1.33.  
Old versions of Microchip software can be downloaded from:
   https://www.microchip.com/development-tools/pic-and-dspic-downloads-archive

To compile an updated version of the firmware make the project "Terminal" the main project.  
Then recompile it.  The resultant hex file is called:
  Source\Terminal\Terminal\dist\default\production\Terminal.production.hex

Updates must be loaded with the standard Microchip bootloader.  This and instructions are in the PC App folder.

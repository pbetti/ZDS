/*	File:	time.c
 *
 *
 *
 *	This is the file that gets the current time/date.
 */



#include "link.h"
#include <time.h>


extern	unsigned char	dateb[];
extern	unsigned char	timeb[];

struct tm	*localtime();




/* get the current date and time */

#define	XTIME	struct tm

long	itime;
static	unsigned char	xdigit[3];
static	char	*xmod[] =
{
	"Jan.",
	"Feb.",
	"March",
	"April",
	"May",
	"June",
	"July",
	"Aug.",
	"Sept.",
	"Oct.",
	"Nov.",
	"Dec."
};




gettime()
{
	register	XTIME		*tp;
	register	unsigned char	*xp;



	time(&itime);
	tp = localtime(&itime);
	xp = (unsigned char *) xmod[tp->tm_mon];
	sprintf(dateb,"%s %d, 19%02d",xp,tp->tm_mday,tp->tm_year);
	sprintf(timeb, "%d:%02d:%02d", tp->tm_hour, tp->tm_min, tp->tm_sec);
}

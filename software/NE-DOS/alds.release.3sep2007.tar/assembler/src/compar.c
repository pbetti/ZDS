/*	File:	compar.c
 *
 *	Contains:	compar, len, match
 *
 *	General purpose string comparison routine
 */




#include "asm.h"


/*.
*************************************************************************
*									*
*	len								*
*	---								*
*									*
*	get the length of a string					*
*									*
*									*
*									*
*************************************************************************
*/

int len(string)
register char *string;
{
	register char *ptr = string;
	
	while (*ptr++)
		;

	return(ptr - string - 1);
}


/*.
*************************************************************************
*									*
*	match								*
*	-----								*
*									*
*	see if two strings match					*
*									*
*									*
*									*
*************************************************************************
*/
int match(s1, s2, flag)
register char *s1, *s2;
char flag;
{
	if (flag == 0)
	{
		while(*s1++ == *s2++)
			if ((*s1++ | *s2++) == 0)
				return(1);

		return(0);
	}

	while( (((*s1 >= 'A') && (*s1 <= 'Z')) ? *s1 + ' ' : *s1) ==
	       (((*s2 >= 'A') && (*s2 <= 'Z')) ? *s2 + ' ' : *s2) )
	{
		if ((*s1++ | *s2++) == 0)
			return(1);
	}

	return(0);
}

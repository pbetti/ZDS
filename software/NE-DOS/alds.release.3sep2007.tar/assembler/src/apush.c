/*	File:	apush.c
 *
 *	Contains:	apush, apop
 *
 *	These are the APUSH, APOP pseudo-op handlers.
 */


#include "asm.h"

static	char	asavei[2] = {0,0};
static	char	asavel = 0;
static	char	asavem = 0;
static	char	asavec = 0;



APUSHLST	pustab[] =
{
	"using", UUSING,
	"print", UPRINT,
	0,		0,
};




void apush()
{
	register char	token;


	if (is_on(AFPUSH))
	{
		eror('O');
		return;
	}

	linpnt = skipsp(linpnt);

	while(notend(linpnt))
	{
		token = find();

		switch(token)
		{
		case UUSING:
			if (is_off(AFUSNG))
			{
				dnops();
				return;
			}

			turn_off(AFUSNG);
			asavei[0] = usin1[0];
			asavei[1] = usin1[1];
			usin1[0] = 0;
			usin1[1] = 0;
			break;

		case UPRINT:
			asavel = lstoff;
			asavem = print_mac;
			asavec = print_con;
			lstoff = 0;
			print_mac = 1;
			print_con = 0;
			break;

		default:
			eror('S');
			break;
		}

		if (*linpnt == COMMA)
			++linpnt;
	}

	turn_on(AFPUSH);
}





void apop()
{
	register char	token;


	if (is_off(AFPUSH))
	{
		eror('S');
		return;
	}

	linpnt = skipsp(linpnt);

	while(notend(linpnt))
	{
		token = find();

		switch(token)
		{
		case UUSING:
			if ((asavei[0] | asavei[1]) == 0)
			{
				eror('S');
				return;
			}

			turn_on(AFUSNG);
			usin1[0] = asavei[0];
			usin1[1] = asavei[1];
			asavei[0] = 0;
			asavei[1] = 0;
			break;

		case UPRINT:
			lstoff = asavel;
			print_mac = asavem;
			print_con = asavec;
			asavel = 0;
			asavem = 0;
			asavec = 0;
			break;

		default:
			eror('S');
			break;
		}

		if (*linpnt == COMMA)
			++linpnt;
	}

	turn_off(AFPUSH);
}





#ifdef M68000
static
#endif
int find()
{
	register APUSHLST	*fp;


	fp = pustab;

	while(fp->a_name[0])
	{
		if (match(fp->a_name, linpnt, 1))
		{
			linpnt += strlen(fp->a_name);
			return(fp->a_token);
		}

		++fp;
	}

	return(0);
}

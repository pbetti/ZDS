/*	File:	printl.c
 *
 *	Contains:	printl, eprintl, scan
 *
 *	This is a general purpose display output routine.
 */



#include "asm.h"

extern	int	xquiet;
static	int	c;




/*VARARGS*/
void printl(fmt, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10)
char	*fmt;
int	*arg1, *arg2, *arg3, *arg4, *arg5, *arg6, *arg7, *arg8, *arg9, *arg10;
{
	register char	*pnt;
		 char	buff[300];


	if (xquiet)
		return;

	(void) sprintf(buff, fmt, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
	pnt = buff;

	while(*pnt)
	{
		if (*pnt == '\n' || *pnt == '\r')
		{
			*pnt = '\n';
			c = 0;
		}
		else if (*pnt == '\t')
			c += c % 8;

		if (logfile || c < 78)
		{
			if (logfile)
			{
				(void) fprintf(logfile, "%c", *pnt);
				(void) fflush(logfile);
			}
			else
				(void) fprintf(stderr, "%c", *pnt);

			++c;
		}

		++pnt;
	}
}


void eprintl(pnt)
char *pnt;
{
	register unsigned char	*pnt1;
		 char	tgname[100];
	/*char * look();			/*<3>*/

	if (passno == 1)
		return;

	(void) strcpy(tgname, (*incpnt) ? incpnt : savebuf);
	
	if (pnt1 = search(tgname))
		*pnt1 = 0;

	printl("%s:\t%s", look(tgname), pnt);

	if (logfile)
		(void) fflush(logfile);
}

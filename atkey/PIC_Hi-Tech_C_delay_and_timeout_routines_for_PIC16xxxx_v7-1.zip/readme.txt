Delay and Timeout Routines

For Hi-Tech C only.

To use the delay routines, add 'delay.c' as a node to your project in MPLab, and 
the line #include "delay.h" in your project.

Alternatively, you can simply add the line #include "delay.c" to your project.

You can trust these routines - these delay routines were used successfully in a 
commercial product with over 2 years of development and 7000 lines of code.

Regards,
Shane Tolmie
www.microchipC.com
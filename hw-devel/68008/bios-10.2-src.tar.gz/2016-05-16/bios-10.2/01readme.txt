DATE:  19-Aug-2015
Subject:  Very early KISS utilities based on Mini-M68K ROM

Files:
  0README.TXT - This README file
  COPYING    -- GPL v3 license
  KISS01.BIN -- 48k BIOS derived from the Mini-M68K ROM
  CPM68.BIN  -- beginning to work [limping?] CPM-68 (can list ROMdisk)
  CPM68SM.BIN - ditto, but for 128K ROM
  FAT16.ZIP  -- *.OUT files to write to a CF card FAT16 file system
		bootable from KISS01 BIOS
  TEST??.ZIP -- ROM memory test programs (see included README.txt)
  KISS??.ZIP -- BIOS source code
  


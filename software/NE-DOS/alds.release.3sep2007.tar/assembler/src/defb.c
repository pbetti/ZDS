/*.
*************************************************************************
*									*
*	defb and defw handlers						*
*									*
*									*
*									*
*									*
*************************************************************************
*/

#include "asm.h"



/*.
*************************************************************************
*									*
*									*
*	defb handler							*
*									*
*									*
*									*
*************************************************************************
*/
void grp5()
{
	register unsigned char	*bp;
	register unsigned char	*lp;
	register int	loopcount;
		 short	value1, value2, save_bglob = 0, save_refpno = 0;


#if DEBUG
printf("group 5 (defb)\n");
#endif

	if (labbuf[0])
	{
		save_bglob = bglob;
		save_refpno = refpno;

		if ((passno == 2) && objfile)
		{
			proces();
			putobj();
		}
	}

	loopcount = 0;
	lp = linpnt;

	while(notend(lp))
	{
		initl(0);
		lstcnt = 1;
		bp = getvalue(lp);
		eval(lp);
		value1 = evalue;

		if (*bp == '%')
		{
			if (mathfg & MFEXT)
			{
				dnops();
				return;
			}
			
			lp = ++bp;
			bp = getvalue(lp);
			eval(lp);
			value2 = evalue;
			chkof(value2);
			

			if (value1 > ACBSIZ)
			{
				dnops();
				value1 = ACBSIZ;
			}

			while(value1--)
			{
				asscod[ascdno++] = (unsigned char) value2;
/*
 * code needs to be added here
 * to properly handle "x%(relo)"
 * 	things to check:
 *	1> was a external or relo label used
 *	2> was the high/low operators used
 *	3> if the high/low operators were not used,
 *	   set the low only flag
 */
				
			}

			lstcnt = LBYTES;
		}
		else
		{
			asscod[ascdno++] = (unsigned char) value1;
			if ((hilow & O4MSB) || (hilow & O4LSB))
			{
				turn_on(AFHILO);
			}
		}

		adjarc();

		if (passno == 2)
		{
			proces();

			if (loopcount)
				xxobj();
			else
			{
				bglob = save_bglob;
				refpno = save_refpno;
				lstln();
			}

			if (objfile)
			{
				adroff = -1;
				putobj();
			}
		}

		ascdno = 0;
		addisr = adrefc[mode];
		
		if (!(chkspc(bp) || term(bp)))
			++bp;

		lp = bp;
		++loopcount;
	}

	initl(0);
	dont = 1;
	lstcnt = LBYTES;
}


/*.
*************************************************************************
*									*
*									*
*	defw handler							*
*									*
*									*
*									*
*************************************************************************
*/
void grp6()
{
	register unsigned char	*lp, *bp;
	register int	loopcount;
		 short	value1, value2, save_bglob = 0, save_refpno = 0;


#if DEBUG
printf("group 6 (defw)\n");
#endif

	if (labbuf[0])
	{
		save_bglob = bglob;
		save_refpno = refpno;

		if (passno == 2 && objfile)
		{
			proces();
			putobj();
		}
	}

	loopcount = 0;
	lp = linpnt;
	
	while(notend(lp))
	{
#if DEBUG
printf("defw: *%s*\n",lp);
#endif

		initl(0);
		lstcnt = 2;
		bp = getvalue(lp);
		eval(lp);
		value1 = evalue;

		if (*bp == '%')
		{
			if (mathfg & MFEXT)
			{
				dnops();
				return;
			}
			
			lp = ++bp;
			bp = getvalue(lp);
			eval(lp);
			value2 = evalue;
			

			if (value1 > (ACBSIZ / 2))
			{
				dnops();
				value1 = ACBSIZ / 2;
			}

			while(value1--)
				appwd(value2);

			lstcnt = LBYTES;
		}
		else
		{
			adroff = -1;
			appwd(value1);

			if (hilow & (O4MSB | O4LSB))
				turn_on(AFHILO);
		}

		adjarc();

		if (passno == 2)
		{
			proces();

			if (loopcount)
				xxobj();
			else
			{
				bglob = save_bglob;
				refpno = save_refpno;
				lstln();
			}

			if (objfile)
			{
				adroff = -1;
				putobj();
			}
		}

		ascdno = 0;
		addisr = adrefc[mode];
		
		if (!(chkspc(bp) || term(bp)))
			++bp;

		lp = bp;
		
#if DEBUG
printf("defw: next *%s*\n",lp);
#endif

		++loopcount;
	}

	initl(0);
	dont = 1;
	lstcnt = LBYTES;
	
#if DEBUG
printf("defw: end with  *%s*\n",lp);
#endif
}


/*.
*************************************************************************
*									*
*									*
*									*
*									*
*									*
*************************************************************************
*/
/*	get pointer to end of next value on line	*/
unsigned char *getvalue(pnt)
register unsigned char *pnt;
{
#if DEBUG
printf("db/dw getvalue\n");
#endif
	for(;;)
	{
		if (*pnt == SQUOTE)
			pnt = skipquote(pnt);

		if (*pnt == ',')
			return(pnt);

		if (chkspc(pnt) || term(pnt))
			return(pnt);

		if (*pnt == '%')
			return(pnt);

		++pnt;
	}

	/*NOTREACHED*/
	return(0);
}

/*	File:	roman.c
 *
 *	Contains:	dr, romc, romd
 *
 *	This is the DEFR handler. It will change a line into roman
 *	numerials.
 */





#include "asm.h"

static	char	*templine = "  -  \t";
static	char	*textline = "\tDEFT\t'";
static	char	tempbuf[50];
static	char	rtpoint;


void defr()
{
	register short	value;
 	register char	*pnt;
 	register unsigned char	*lp;

#if	DEBUG
printf("roman num\n");
#endif

	clrbuf(tempbuf,49);
	rtpoint = 0;

	lp = skipsp(linpnt);
	linpnt = lp;

	if (*lp++ != SQUOTE)
	{
		dnops();
		return;
	}
	
	value = 0;

	while (digit(lp))
		value = (value * 10) + (*lp++ - '0');

	if (*lp != SQUOTE)
		eror('S');

	value = romc('M', 1000, value);
	value = romd("CM", 900, value);

	value = romc('D', 500, value);
	value = romd("CD", 400, value);

	value = romc('C', 100, value);
	value = romd("XC", 90, value);

	value = romc('L', 50, value);
	value = romd("XL", 40, value);

	value = romc('X', 10, value);
	value = romd("IX", 9, value);

	value = romc('V', 5, value);
	value = romd("IV", 4, value);

	(void) romc('I', 1, value);

	tempbuf[rtpoint++] = SQUOTE;
	tempbuf[rtpoint++] = CRLF;
	tempbuf[rtpoint] = 0;

	lstln();

	(void) strcpy(numbbb, templine);
	
	pnt = textline;
	lp = minbuf;

	while(*pnt)
		*lp++ = *pnt++;

	*lp = 0;
	(void) strcat(minbuf, tempbuf);


	/* force to DEFT and let defm handle the string */
	ortkbf[1] = 1;
	linpnt = lp;
	defm();
}




short romc(token, max, value)
register char token;
register short  max, value;
{
	while(value >= max)
	{
		value -= max;
		tempbuf[rtpoint++] = token;
	}

	return(value);
}



short romd(tp, max, value)
register char *tp;
register short  max, value;
{
	if (value >= max)
	{
		value -= max;
		tempbuf[rtpoint++] = tp[0];
		tempbuf[rtpoint++] = tp[1];
	}

	return(value);
}

/*	xs_man.c

	MAN for Samarux.

	Manual.

	Copyright (c) 2007 - 2015 Miguel I. Garcia Lopez.

	This program is free software; you can redistribute it and/or modify it
	under the terms of the GNU General Public License as published by the
	Free Software Foundation; either version 2, or (at your option) any
	later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

	Usage:

	man [topic | all]

	Examples:

	man      -- To print all available topics
	man cat  -- To print topic help
	man ALL  -- To print all contents

	Changes:

	19 Dec 2014 : 1.00 : 1st version.
	24 Dec 2014 : 1.01 : Minor changes.
	30 Dec 2014 : 1.02 : Added \n to the start of sections.
	04 Jan 2015 : 1.03 : Added NOTES section.
	08 Jan 2015 : 1.04 : Changed man file constant. Minor changes. Added comments.
	12 Jan 2015 : 1.05 : Added option to print all contents.
	17 Feb 2015 : 1.06 : Close file if not enough memory for buffer.
*/

ManMain(argc, argv)
int argc, argv[];
{
	FILE *fp;
	char *bf;
	int k, err, flg_found, flg_output, opt_topics, opt_all;

	/* Check arguments */

	if(argc == 1)
		opt_topics = 1;
	else if(argc == 2)
	{
		opt_topics = opt_all = flg_output = flg_found = 0;

		if(!strcmp(argv[1], "ALL"))
		{
			++opt_all; ++flg_found;
		}
	}
	else
		return ErrorPars();

	/* Open */

	if((fp = fopen(SX_MANFILE, "r")) == NULL)
		return ErrorOpen();

	/* Buffer */

	if((bf = malloc(sv_tty_cols)) == NULL)
	{
		fclose(fp);

		return ErrorMem();
	}

	err = 0;

	/* Process */

	while(1)
	{
		/* Read line */

		if(fgets(bf, sv_tty_cols, fp) == NULL)
			break;

		k = strlen(bf);

		if(bf[k - 1] != '\n')
		{
			err = ErrorTooLong(); break;
		}

		bf[k - 1] = 0;

		/* Print available topics */

		if(opt_topics)
		{
			if(*bf == '@')
				puts(bf + 1);

			continue;
		}
	
		/* Print topic help / all topics help */

		if(flg_found)
		{
			/* Check end of topic section */

			if(*bf == '@')
			{
				if(opt_all)
					continue;

				break;
			}				

			/* Print section titles */

			if(*bf == '$')
			{
				if(flg_output)
					putchar('\n');

				if(!strcmp(bf + 1, "NM"))
					puts("NAME");
				else if(!strcmp(bf + 1, "SY"))
					puts("SYNOPSIS");
				else if(!strcmp(bf + 1, "DE"))
					puts("DESCRIPTION");
				else if(!strcmp(bf + 1, "OP"))
					puts("OPTIONS");
				else if(!strcmp(bf + 1, "EX"))
					puts("EXAMPLES");
				else if(!strcmp(bf + 1, "NT"))
					puts("NOTES");
				else
				{
					err = Error("Unknown $section"); break;
				}
			}
			else if(*bf != '#')
			{
				putchar('\t'); puts(bf); ++flg_output;
			}

			continue;
		}

		/* Find topic section */

		if(*bf == '@')
		{
			if(!strcmp(bf + 1, argv[1]))
				++flg_found;
		}
	}

	/* Close */

	fclose(fp);

	/* Free buffer */

	free(bf);

	/* Failure? */

	if(!flg_found && !opt_topics)
		return Error("Topic not found");

	/* Return success or failure */

	return err;
}


/*	File:	title.c
 *
 *	Contains:	title, header
 *
 *	This routine is the handler for the TITLE/HEADER pseudo-op.
 *	It will move the title (if any) to the proper buffer.
 */




#include "asm.h"







/*.
*************************************************************************
*									*
*									*
*									*
*									*
*									*
*************************************************************************
*/
void setbufx(buf)
register char *buf;
{
	register int	lenx;
	register unsigned char	*lp;

	/*
	 * skip leading spaces
	 */
	lp = linpnt;
	
	if (*lp == SQUOTE)
		++lp;
	else
		eror('S');

	/*
	 * see if it's pass 1. exit if so
	 */
	if (passno == 1)
		return;

	/*
	 * if we have text, install it
	 */
	if (lenx = str(lp))
		lp = movbuf(lp, buf, lenx, 0);

	*lp = 0;
	dont = 1;
}



/*.
*************************************************************************
*									*
*	title								*
*	-----								*
*									*
*	handle the title buffer 					*
*									*
*	int title()							*
*									*
*	returns no value						*
*									*
*************************************************************************
*/
void title()
{
#if   DEBUG
printf("title\n");
#endif
	setbufx(titbuf);
}


/*.
*************************************************************************
*									*
*	header								*
*	------								*
*									*
*	handle the header buffer 					*
*									*
*	header()							*
*									*
*	returns no value						*
*									*
*************************************************************************
*/
void header()
{
	extern	char	ffchar[];

#if DEBUG
printf("header\n");
#endif
	setbufx(hedbuf);

	if (ffchar[0])
		ffeed();
}

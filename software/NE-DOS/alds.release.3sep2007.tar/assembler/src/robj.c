/*	File:	robj.c
 *
 *	Contains:	robj
 *
 *	This is the handler for the OBJ pseudo-op.
 */




#include "asm.h"




void robj()
{
	register int	lenx;
	register unsigned char	*lp;

	/*
	 * skip leading spaces
	 */
	lp = linpnt;
	
	if (*lp == SQUOTE)
		++lp;
	else
		eror('S');

	/*
	 * see if it's pass 1. exit if so
	 */
	if (passno == 2)
		return;

#if DEBUG
printf("robj\n");
#endif

	/*
	 * if we have text, install it
	 */
	if (lenx = str(lp))
		lp = movbuf(lp, objname, lenx, 0);

	*lp = 0;
	dont = 1;
}

/*  Main equate module */

#include "asm1.h"


/*	assmebler storage declarations		*/

extern	FILE	*errfile;
extern	FILE	*imdfile;
extern	FILE	*infile;
extern	FILE	*lisfile;
extern	FILE	*logfile;
extern	FILE	*objfile;

extern	LIT	*litbeg;	/* pointer to beginning of literals */
extern	LIT	*litend;	/* pointer to end of literals */

extern	MAC	*macbeg;	/* pointer to start of macro list */
extern	MAC	*macend;	/* pointer to last macro */

extern	SYM    	*symbeg;	/* beginning of symbol table */

extern	unsigned char	*incpnt;	/* pointer to include file name */
extern	unsigned char	*linpnt;	/* pointer into input line buffer */

extern	char	adjflg;		/* flag for adjust pc */
extern	char	bglob;		/* flag for list routine */
extern	char	condi1;		/* secondary conditional flag */
extern	char	conflg;		/* flag shows conditionals on */
extern	char	dont;		/* listing flag */
extern	char	false_condit;	/* conditional flag */
extern	char	filflg;		/* 'fill' flag */
extern	char	flpseg;		/* block comment flag */
extern	char	frstsw;		/* first time switch for chkhed() */
extern	char	hdchg;		/* END header change */
extern	char	hdflag;		/* '06' header flags */
extern	char	idef;		/* present isect number */
extern	char	isave2;		/* save for isect number check */
extern	char	labflg;		/* flag for processed label */
extern	char	lglob;		/* global flag */
extern	char	line;		/* number of lines this page */
extern	char	lstcnt;		/* reset the listing byte count */
extern	char	lstoff;		/* listing flags */
extern	char	mode;		/* mode of the assembler */
extern	char	opnrec;		/* flag to show open record */
extern	char	outchg;		/* reset the 04 header byte */
extern	char	parflg;		/* used by expression */
extern	char	passno;		/* assembler pass number */
extern	char	patflg;		/* patch flag */
extern	char	pdef;		/* present psect number */
extern	char	pfirst;		/* psect first time switch */
extern	char	plchg;		/* plit radix */
extern	char	print_con;	/* conditional listing flag */
extern	char	print_mac;	/* macro listing control flag */
extern	char	print_short;	/* int/long listing flag */
extern	char	ps;		/* flag for multi psects */
extern	char	psave;		/* insure listing match of psect */
extern	char	radix;		/* current evaulation radix (base) */
extern	char	refflg;		/* flag to show we're in a ref */
extern	char	refpno;		/* flag for symbol referenced */

extern	int	slenth;		/* length of a symbol */
extern	int	addisr;		/* pc for listing counter */
extern	int	adrefc[];	/* pc counter */
extern	int	adroff;		/* address offset */
extern	int	ascdno;		/* number of bytes in code buffer */
extern	int	bycnt;		/* byte count of program */
extern	int	chksum;		/* checksum for intel hex output */
extern	int	eaddr;		/* '06' header address */
extern	int	encode;		/* encrypt value for DEFE */
extern	int	entadr;		/* address for entry */
extern	int	errcnt;		/* assembler error counter */
extern	int	evalue;		/* value save */
extern	int	fast;		/* no listing wanted flag */
extern	int	file_no;	/* current file number */
extern	int	filenum;	/* internal file number counter */
extern	int	hilow;		/* high/low flags */
extern	int	hladdr;		/* used for high/low */
extern	int	ifcnt;		/* 'if' counter */
extern	int	inccnt;		/* include counter */
extern	int	isave;		/* address save for isect */
extern	int	litcnt;		/* litorg literal counter */
extern	int	litnum;		/* literal number */
extern	int	locnum;		/* local label number */
extern	int	dolog;		/* nz = logfile being written */
extern	int	macnum;		/* number of macros */
extern	int	mathfg;		/* math flags */
extern	int	mlocnum;	/* macro local label number */
extern	int	o4cnt;		/* bytes in 04 header */
extern	int	ocount;		/* object buffer count */
extern	int	offset;		/* phase (setloc) offset */
extern	int	opbyt1;		/* operand token 1 */
extern	int	opbyt2;		/* operand token 2 */
extern	int	page;		/* listing page number */
extern	int	rlist;		/* display lines to video for test */
extern	int	sline;		/* number of source lines */
extern	int	symcnt;		/* count for cross reference output */
extern	int	topaddr;	/* highest address of pgm */

extern	long	aflags;		/* assembler flags */

extern	unsigned char	asscod[];	/* assembly code buffer */
extern	unsigned char	dateb[];	/* date buffer */
extern	unsigned char	errbuf[];	/* error buffer */
extern	unsigned char	hedbuf[];	/* header buffer */
extern	unsigned char	ifstk[];	/* conditional stack */
extern	unsigned char	labbuf[];	/* label buffer */
extern	unsigned char	lline[];	/* listing line buffer */
extern	unsigned char	minbuf[];	/* disk line input buffer */
extern	unsigned char	numbbb[];	/* buffer for line number */
extern	unsigned char	o4entb[];	/* 04 entry name buffer */
extern	unsigned char	o4extb[];	/* 04 external name buffer */
extern	unsigned char	objbuf[];	/* object code buffer */
extern	unsigned char	objname[];	/* buffer for object file name */
extern	unsigned char	ortkbf[];	/* operator token buffer */
extern	unsigned char	pbuffr[];	/* psect name buffer */
extern	unsigned char	ptable[];	/* psect header table */
extern	unsigned char	savebuf[];	/* buffer for source file name */
extern	unsigned char	symbuf[];	/* work buffer for token operations */
extern	unsigned char	timeb[];	/* time buffer */
extern	unsigned char	titbuf[];	/* title buffer */
extern	unsigned char	tx1[];		/* temp buffer 1 */
extern	unsigned char	tx2[];		/* temp buffer 2 */
extern	unsigned char	tx3[];		/* temp buffer 3 */
extern	unsigned char	usin1[];	/* using number buffer */

extern	unsigned int	odint1;		/* operator token 1 */
extern	unsigned int	odint2;		/* operator token 2 */

This zip archive contains the Propeller firmware
for the PropIO V2.  This firmware is specifically
to enable operation with RomWBW.

The PropIO2.eeprom file should be programmed onto
the onboard 24C512 serial eeprom.  This is normally
accomplished using Parallax Propeller Tool.
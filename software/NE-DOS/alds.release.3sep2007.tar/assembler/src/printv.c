/*	File:	print.c
 *
 *	Contains:	printv
 *
 *	This is the handler for the PRINT pseudo-op.
 */




#include "asm.h"

PRTLST	prtlst[] =
{
	"on",		ON,
	"off",		OFF,
	"all",		ALL,
	"mac",		MACP,
	"con",		CON,
	"lst",		ON,
	"long",		LONG,
	"short",	SHORT,
	"nomac",	NOMAC,
	"nocon",	NOCON,
	"nolst",	OFF,
	0,		0,
};





void printv()
{
	register PRTLST	*fp;
	register unsigned char	*lp;

#if DEBUG
printf("printv: %s\n", linpnt);
#endif

	if (false_condit)
		return;

	lp = skipsp(linpnt);

	while(!term(lp))
	{
		if (alpha(lp) == 0)
			break;

		lp = gsym(lp, symbuf);
		fp = yfind();

		switch(fp->p_token)
		{
		case ON:
			lstoff &= LTON;
			break;

		case OFF:
			lstoff |= LTOFF;
			break;

		case ALL:
			lstoff = 0;
			print_mac = 1;
			print_con = 1;
			print_short = 0;
			break;

		case MACP:
			print_mac = 1;
			break;

		case CON:
			print_con = 1;
			break;

		case LONG:
			print_short = 0;
			break;

		case SHORT:
			print_short = 1;
			break;

		case NOMAC:
			print_mac = 0;
			break;

		case NOCON:
			print_con = 0;
			break;

		default:
			eror('S');
			return;
		}

		lp = skipsp(lp);

		if (*lp == COMMA)
			++lp;
	}

	dont = 1;
}





PRTLST *yfind()
{
	register PRTLST	*fp;


	fp = prtlst;

	while(fp->p_name[0])
	{
#if DEBUG
printf("find: %s %s\n", fp->p_name, symbuf);
#endif
		if (match(fp->p_name, symbuf, 1))
			return(fp);

		++fp;
	}

	return(0);
}

/*	File:	error.c
 *
 *	Contains:	eror, synerr, errorl, errorv
 *			errorp, errorc, errort, errors, errorm
 *			errorw, errore, dnops, prterr
 *
 *	These are the error handlers.
 */


#include "asm.h"

extern	char	eabort;
extern	int	erabort;
extern	int	xrefyes;
extern	int	xscreen;



static	short	erpage = -1;	/* last error page number */
static	char	ehold[] = "/tmp/#aldsXXXXXX";
	char	errname[] = "/tmp/#aldsXXXXXX";
static	char	ernt[] = "\nAborting assembly due to %u errors\n";


/*.
*************************************************************************
*									*
*	eror								*
*	----								*
*									*
*									*
*									*
*									*
*************************************************************************
*/
void eror(c)
char c;
{
	if (false_condit || is_on(DMACRO) || errbuf[0] != SPACE)
		return;

#if DEBUG
printf("error: %c\n", c);
#endif

	errbuf[0] = c;

	if (passno == 1)
		return;

	++errcnt;

	if (eabort && errcnt > erabort)
	{
		printl(ernt, errcnt);

		if (lisfile)
		{
			(void) fprintf(lisfile, ernt, errcnt);

			if (xscreen == 0 && lisfile)
			{
				(void) fclose(lisfile);
				lisfile = 0;
			}
		}

		if (logfile)
		{
			(void) fclose(logfile);
			logfile = 0;
		}

		xdone(1);
	}

	outerr();
}

void dnops()
{
	if (is_on(DMACRO))
		return;

	eror('S');
	clrbuf(asscod, 6);
	ascdno = 4;
	lstcnt = LBYTES;
	mathfg &= ~MFSYRL;
}


/*.
*************************************************************************
*									*
*	outerr								*
*	------								*
*									*
*	output the error page to a disk file				*
*									*
*									*
*									*
*************************************************************************
*/
void outerr()
{
	short	epage;

	if (passno == 1 || fast || xrefyes || is_on(DMACRO))
		return;

	epage = page - 1;

	if (erpage == epage)
		return;

	if (!errfile)
	{
		(void) strcpy(errname, ehold);

		if ((errfile = xcreate(mktemp(errname))) == 0)
		{
			printl("\nCan't create error file\n");
			xdone(0);
		}
	}

	erpage = epage;
	(void) fprintf(errfile, "%4d\n", epage);
}


/*.
*************************************************************************
*									*
*	prterr								*
*	------								*
*									*
*									*
*									*
*									*
*************************************************************************
*/
void prterr()
{
	register char	*comma;
	register int	count;
		 char	epage[5];


	comma = "";
	rewind(errfile);

	if (errcnt == 1)
		(void) fprintf(lisfile,"Error Page:\t");
	else
		(void) fprintf(lisfile,"Error Pages:\t");

	count = 0;

	while (fgets(epage,6,errfile))
	{
		epage[4] = 0;

		(void) fprintf(lisfile,"%s%s",comma,epage);

		if (++count == 15)
		{
			count = 0;
			lfeed();
			(void) fprintf(lisfile,"\t\t");
			comma = "";
		}
		else
			comma = ", ";
	}

	lfeed();
}

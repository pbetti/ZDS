/*	File:	getline.c
 *
 *	Contains:	getline
 *
 *	These routines read in one line of source from the input file
 *	into the line buffer.
 */




#include "asm.h"


int getline()
{
	register unsigned char	*lp;

#if DEBUG
printf("getline\n");
#endif

	(void) sprintf(numbbb, "%5u\t", sline++);

	if (fgets(minbuf, 180, infile) == 0)
		return(EOF);

	lp = &minbuf[strlen(minbuf) - 1];

	if (*lp == '\n')
		*lp = 0;

	return(0);
}

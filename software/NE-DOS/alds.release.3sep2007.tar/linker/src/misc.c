/*	File:	misc.c
 *
 *	Contains:
 *
 *	Misc routines for the alds linker
 */


#include "link.h"



extern	unsigned int	lineno;
extern	unsigned char	passno;
extern	unsigned char	*head1;
extern	unsigned char	*head2;
extern	unsigned char	sdate[];
extern	unsigned char	sxtime[];
extern	unsigned char	sourcename[];
extern	FILE	*mapfile;

static	unsigned char	first = 0;

unsigned char	toupper();
unsigned char	tolower();





makelower(buff)
register unsigned char	*buff;
{
	while(*buff)
	{
		*buff = tolower(*buff);
		++buff;
	}
}



unsigned char toupper(byte)
unsigned char	byte;
{
	if((byte >= 'a') && (byte <= 'z'))
		return(byte - ' ');
	else	return(byte);
}



unsigned char tolower(byte)
unsigned char	byte;
{
	if((byte >= 'A') && (byte <= 'Z'))
		return(byte + ' ');
	else	return(byte);
}



isdigit(byte)
unsigned char	byte;
{
	if((byte >= '0') && (byte <= '9'))
		return(1);
	else	return(0);
}



isalpha(byte)
unsigned char	byte;
{
	byte = tolower(byte);

	if((byte >= 'a') && (byte <= 'z'))
		return(1);
	else	return(0);
}


an(byte)
unsigned char	byte;
{
	if((byte == '_') || (byte == '@') || (byte == '?') || (byte == '$'))
		return(1);

	else if(isalpha(byte))
		return(1);
	else
		return(isdigit(byte));
}


ishex(byte)
unsigned char	byte;
{
	byte = tolower(byte);

	if(isdigit(byte))
		return(1);

	if((byte >= 'a') && (byte <= 'f'))
		return(1);
	else 	return(0);
}




unsigned char *skipsp(pnt)
register unsigned char	*pnt;
{
	while((*pnt == ' ') || (*pnt == '\t'))
		++pnt;

	return(pnt);
}




equal(pnt1, pnt2)
unsigned char	*pnt1, *pnt2;
{
	unsigned char	buff1[100];
	unsigned char	buff2[100];

	strcpy(buff1, pnt1);
	makelower(buff1);
	strcpy(buff2, pnt2);
	makelower(buff2);
	return(strcmp(buff1, buff2) == 0);
}





list(buffer)
register unsigned char	*buffer;
{
	if(passno == 1)
		return;

	if((++lineno == MAXLINE) || (!first))
		eject();

	if(mapfile)
		fprintf(mapfile, "%s\n", buffer);
	else
		printl("%s\n", buffer);
}





eject()
{
	unsigned char	buff[200];


	lineno = 0;

	if(first && mapfile)
		fprintf(mapfile, "\f");
	else	first = 1;

	sprintf(buff, "ALDS Vax Linker\tVersion 1.0\t%s\t%s", sdate, sxtime);
	list(buff);
	sprintf(buff, "Link Map for: %s", sourcename);
	list(buff);
	list("");
	list(head1);
	list(head2);
	list("");
}




unsigned char hexasc(byte)
unsigned char	byte;
{
	byte &= 0xf;
	return(byte > 9 ? byte + '7' : byte + '0');
}



clrbuf(buff, count)
register unsigned char	*buff;
register unsigned int	count;
{
	register	unsigned int	i;

	for(i = 0; i < count; i++)
		buff[i] = 0;
}

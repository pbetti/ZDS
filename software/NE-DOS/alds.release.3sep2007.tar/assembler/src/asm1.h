/*	File:	asm.h
 *
 *	Assembler equates, definitions, and macros.
 */

#include <stdio.h>
#ifdef M68000
#include <void.h>
#endif



#define	NUM_BYTES	2
#define	HITACHI		/* define this for extended hitachi cpu instructions */

/*	The following is to define DEBUG mode. If debug mode is
 *	wanted, change the value to 1.
 */

#define	DEBUG	0

/*	The following sets up the number of segments (aseg, cseg, etc) that
 *	are used for the pc counter. If this value is changed, be sure to
 *	change 'adrefc' in buff.c
 */

#define	SEGMENTS	3
#define	ASEG		0
#define	CSEG		1
#define	DSEG		2


/*
 *	binary lookup equates used with check()
 */
#define	TOO_LOW		(-1)
#define MATCH		0
#define TOO_HIGH	1


/*	following are general (in nature) equates	*/
#define	BUFSIZE	512
#define	BYTMSK	0xff
#define	ERR	(-2)

#define	EMPTY	0
#define	MORE	1
#define	DUMMY	2



/*	maximum sizes allowed	*/
#define	CONLEV	10		/* maximum nesting level of conditionals */
#define	INCLEV	7		/* maximum nesting of includes */
#define	MACLEV	10		/* maximum nesting level of macros */
#define	MAXLIT	40		/* maximum number of litorg literals */
#define	MAXMAC	100		/* maximum number of macros */
#define	MAXOBJ	252		/* maximum number of bytes in obj buff */
#define	MAXOBJA	252		/* maximum number of bytes in absolute mode */
#define	MAXOBJR	28		/* maximum number of bytes in relo mode */
#define	MAXSYM	5000		/* maximum number of symbols in sym table */





/*	following are equates for the symbol table status byte attached
 *	to every symbol  (first byte 's_flag1')
 */
#define	SYMUDF	1	/* undefined symbol (public not yet defined) */
#define	SYMMDF	2	/* multipally defined symbol */
#define	SYMSEC	4	/* symbol is marked as ISECT symbol */
#define	SYMEXT	8	/* symbol is marked as EXTERNal symbol */
#define	SYMENT	0x10	/* symbol is marked as ENTRY symbol */
#define	SYMREL	0x20	/* symbol is marked as RELOCATABLE symbol */
#define	SYMREF	0x40	/* symbol is marked as REFerence symbol */
#define	SYMGBL	0x80	/* symbol is marked as GLOBAL symbol */
#define	SYMDFL	(SYMGBL | SYMREF)

/*	(second byte 's_flag2')		*/
#define	PRTGBL	1	/* print 'g' on listing (global symbol) */
#define	PNOREF	2	/* print '-' on listing (no reference) */
#define	SYMLOC	4	/* symbol is a local label */
#define	MACLOC	8	/* symbol is a local from macro */
#define	SLOCAL	(SYMLOC | MACLOC)
#define	SYDSEG	0x10	/* symbol is a dseg */

/*
 *	macros for AFLAGS
 */
#define	turn_on(name)	(aflags |= (name))
#define turn_off(name)	(aflags &= ~(name))
#define is_on(name)	(aflags & (name))
#define	is_off(name)	((aflags & (name)) == 0)

/*
 *	following equates are for the assembler flags byte 1
 */
#define	AFADIS	0x00000001L	/* address discontinuity has occured */
#define	AFENDS	0x00000002L	/* end statement encountered on input source */
#define	AFSYOF	0x00000004L	/* symbol table overflow has occured */
#define	AFASEG	0x00000008L	/* absolute mode assembly in progress */
#define	AFLINK	0x00000010L	/* a link instruction has been encountered */
#define	AFHILO	0x00000020L	/* a 'high'/'low' function was encountered */
#define	AFPATC	0x00000040L	/* 'patch' option is in effect */
#define	AFEQDL	0x00000080L	/* processed an 'equ' or 'defl' operand */

/*
 *	following equates are for the assembler flags byte 2
 */
#define	AFSYMB	0x00000100L	/* indicates that a symbol as on the line */
#define	AFPUSH	0x00000200L	/* 'apush' in effect */
#define	AFUSPR	0x00000400L	/* processing an 'ISECT' label */
#define	AFUSNG	0x00000800L	/* presently in USING mode */
#define	AFISEC	0x00001000L	/* presently in ISECT mode */
#define	AFO4HD	0x00002000L	/* generate on '04' header */
#define	AFENTS	0x00004000L	/* ENTRY symbol being defined */
#define	AFEXTS	0x00008000L	/* EXTERN symbol being defined */

/*	following equates are for the assembler flags byte 3	*/
#define	MACREX	0x00010000L	/* macro expanded */
#define	LINKST	0x00020000L	/* link statement encountered */
#define	AFABSL	0x00040000L	/* label is absolute */
#define	AFDEFM	0x00080000L	/* object is DEFM or DEFT */
#define	AFORG	0x00100000L	/* psect/org processed */
#define	AFLOC	0x00200000L	/* local label */
#define	AFLOCL	0x00400000L	/* processing local label */
#define	AFMLOC	0x00800000L	/* processing macro local label */
#define	AFGLAB	0x01000000L	/* label is from GLAB */
#define	AFGLOC	0x02000000L	/* GLAB processed local label */
#define	DMACRO	0x04000000L	/* macro being defined. no errors please */
#define	AFDSEG	0x08000000L	/* label is a dseg */


/*	following are math flag bit definitions		*/
#define	MFLSTR	0x0001	/* list generation is to be relocatable */
#define	MFOBJR	0x0002	/* code generation is to be relocatable */
#define	MFENT	0x0004	/* ENTRY symbol referenced */
#define	MFEXT	0x0008	/* EXTERNal symbol referenced */
#define	MFJRDJ	0x0010	/* JR or DJNZ instruction encountered */
#define	MFCUFL	0x0020	/* '$' current location counter referenced */
#define	MFSYRL	0x0040	/* relocatable symbol referenced */
#define	MFEQDL	0x0080	/* EQU or DEFL encountered */
#define	MFDSEG	0x0100	/* label is a dseg */

/*	mask for 04 header	*/
#define	MFO4HD	(MFOBJR|MFENT|MFEXT)


/*	mask for relocatable generation		*/
#define	MFRLOF	(~(MFLSTR | MFOBJR | MFEQDL))
#define	MFRLEM	(MFSYRL | MFCUFL)
#define	MFRLEX	(MFRLEM | MFEXT)

/*	mask for absolute code test	*/
#define	MFABSM	(MFEQDL|MFSYRL|MFCURL)


/*	relocation data flags	*/
#define	RLREL	0x01	/* quantity relocatable (own psect or ext) */
#define	RLEXT	0x02	/* quantity relocatable relative to external */
#define	RLLOW	0x04	/* low byte of relocatable quantity taken */
#define	RLHIGH	0x08	/* high byte of relocatable quanity taken */
#define	RLDSEG	0x10	/* symbol is dseg */


/*	evaluation flags	*/
#define	EVLAST	0x10	/* last unit start */
#define	EVOVFL	0x20	/* arithmetic overflow error */
#define	EVVALU	0x40	/* relocation error detected */




/*	following are the 06 header flag byte definitions	*/
#define	O6DSEG	4	/* following contains dsegs */
#define	O6LNK	8	/* following contains a LINK filename */
#define	O6ENT	0x10	/* following contains ENTRYs */
#define	O6GBL	0x20	/* following is a GBL file */
#define	O6EXT	0x40	/* following contains EXTERNals */
#define	O6REL	0x80	/* following is relocatable object */



/*	following are the 04 header flag byte definitions	*/
#define	O4NONE	0	/* use NEITHER lsb or msb */
#define	O4MSB	1	/* use msb only */
#define	O4LSB	2	/* use lsb only */
#define	O4FULL	3	/* use BOTH lsb and msb */
#define	O4OBJR	4	/* object is relocatable */
#define	O4OBJ	8	/* object code is present */
#define	O4ABS	0x10	/* address is absolute (reloc code only) */
#define	O4DSEG	0x20	/* name referenced is a dseg */
#define	O4EXT	0x40	/* EXTERNal name present */
#define	O4ENT	0x80	/* ENTRY name present */

/*	mask to see if any names present	*/
#define	O4NAME	(O4ENT|O4EXT)




/*	following are the 09 header flag byte definitions	*/
#define	O9LIB	0x40	/* library file request */
#define	O9LNK	0x20	/* link file request */
#define	O9GBL	0x10	/* global file request */




/*	following are listing control definitions	*/
#define	LOLST	1	/* list off/on bit */
#define	LOCON	2	/* conditional list on/off bit */
#define	LOMAC	4	/* macro list on/off bit */

/*	listing on/off mask values	*/
#define	LTOFF	LOLST		/* listing off */
#define	LTON	(~LOLST)	/* listing on */

/*	conditional listing on/off mask values	*/
#define	CONOFF	LOCON	/* conditional listing off */
#define	CONON	(~LOCON)	/* conditional listing on */

/*	macro listing on/off mask values	*/
#define	MACOFF	LOMAC	/* macro listing off */
#define	MACON	(~LOMAC)	/* macro listing on */





/*	expression priorities	*/
#define	PRIOR1	1	/* priority 1 (lowest) */
#define	PRIOR2	2
#define	PRIOR3	3
#define	PRIOR4	4
#define	PRIOR5	5
#define	PRIOR6	6
#define	PRIOR7	7	/* priority 7 (highest) */



/*	define the expression tokens	*/
/* one value - flag 0 */
#define RESTOK	PRIOR1
#define	PLUTOK	(1 << 3) + PRIOR7
#define	HGHTOK	(2 << 3) + PRIOR7
#define	LOWTOK	(3 << 3) + PRIOR7
#define	SGNTOK	(4 << 3) + PRIOR1
/* one value - flag 1 */
#define	MINTOK	(5 << 3) + PRIOR7
#define	NOTTOK	(6 << 3) + PRIOR7
#define	ABSTOK	(7 << 3) + PRIOR1
#define	BITTOK	(8 << 3) + PRIOR7
/* two values - flag 0 */
#define	DIPTOK	(9 << 3) + PRIOR4
#define	DIMTOK	(10 << 3) + PRIOR4
/* two values - flag 1 */
#define	ASKTOK	(11 << 3) + PRIOR5
#define	DIVTOK	(12 << 3) + PRIOR5
#define	MODTOK	(13 << 3) + PRIOR5
#define	EXPTOK	(14 << 3) + PRIOR6
#define	SHRTOK	(15 << 3) + PRIOR5
#define	SHLTOK	(16 << 3) + PRIOR5
#define	RRTOK	(17 << 3) + PRIOR5
#define	RLTOK	(18 << 3) + PRIOR5
#define	ANDTOK	(19 << 3) + PRIOR3
#define	ORTOK	(20 << 3) + PRIOR2
#define	XORTOK	(21 << 3) + PRIOR2
/* two values - flag 2 */
#define	EQTOK	(22 << 3) + PRIOR1
#define	GTTOK	(23 << 3) + PRIOR1
#define	GETOK	(24 << 3) + PRIOR1
#define	LTTOK	(25 << 3) + PRIOR1
#define	LETOK	(26 << 3) + PRIOR1
#define	UGTTOK	(27 << 3) + PRIOR1
#define	UGETOK	(28 << 3) + PRIOR1
#define	ULTTOK	(29 << 3) + PRIOR1
#define	ULETOK	(30 << 3) + PRIOR1
#define	LBTOK	(31 << 3)



/*	header bytes	*/
#define	O1H	1	/* 01 header byte */
#define	O2H	2	/* 02 header byte */
#define	O3H	3	/* 03 header byte */
#define	O4H	4	/* 04 header byte */
#define	O6HC	5	/* 06 header byte (aseg) */
#define	O6H	6	/* 06 header byte (relocatable) */
#define	O7H	7	/* 07 header byte (defs) */
#define	O8H	8	/* 08 header byte */
#define	O9H	9	/* 09 header byte */
#define	OAH	10	/* 0A header byte */
#define	OBH	11	/* 0B header byte */
#define	OMAX	12	/* lowest illegal header byte */



/*	assembler equates and definitions	*/
#define	DATLEN	16	/* length of 'date' string */
#define	TIMLEN	8	/* length of 'time' string */
#define	XYMASK	0xfb	/* mask to recognize IX/IY tokens */
#define	IXORIY	0x1a	/* common value of IX/IY tokens */
#define	IXPRE	0xdd	/* prefix for IX instructions */
#define	IYPRE	0xfd	/* prefix for IY instructions */
#define	TWOPRE	0xed	/* prefix for most two type operands */
#define	MAXFSK	10	/* max size of arithmetic function stack */
#define	MAXASK	20	/* max size of arithmetic stack */
#define	LBFSZ	100	/* line buffer size */
#define	ACBSIZ	255	/* object code buffer size */
#define	TITSIZ	130	/* title/header buffer size */
#define	TRMMAX	78	/* max characters to video screen */


/*	listing definitions	*/
#define	PLINES	54	/* number of lines on listing page */
#define	LBYTES	6	/* number of object bytes per listing line */
#define	MPERL	8	/* number of macros per printed line */


/*	symbol table size definitions	*/

#define	MAXLTH 20



/*	the following are assembler character definitions	*/
#define	CRLF	0x0d	/* carriage return */
#define	HT	9	/* tab */
#define	FORMFD	0x0c	/* form feed */
#define	SPACE	0x20	/* space */
#define	COMENT	';'	/* comment designator */
#define	MACRO	'#'	/* parameter specifier for macro definitions */
#define	LOCAL	'.'	/* local label prefix */
#define	MLOCAL	'!'	/* local label within macros prefix */
#define	COMMA	','	/* comma (gee!) */
#define	LITORG	'='	/* character to denote litorg literal */
#define	LPAREN	'('	/* left paren */
#define	RPAREN	')'	/* right paren */
#define	SQUOTE	0x27	/* single quote character */


/*	the following are the token equates for group handlers	*/
#define	NONE	0	/* null token */
#define	ORGTOK	1	/* ORG */
#define	EQUTOK	2	/* EQU */
#define	DEFLTK	3	/* DEFL */
#define	ENDTOK	4	/* END */
#define	DEFBTK	5	/* DEFB */
#define	DEFWTK	6	/* DEFW */
#define	DEFSTK	7	/* DEFS */
#define	DEFMTK	8	/* defm */
#define	TITTOK	9	/* title */
#define	SBTOK	10	/* single byte, no operand */
#define	DBTOK	11	/* double byte, no operand */
#define	AOXCS	12	/* AND, OR, XOR, CP, SUB */
#define	IDTOK	13	/* INC, DEC */
#define	IMTOK	14	/* IM */
#define	RRSRR	15	/* RLC, RL, SLA, RRC, RR, SRA, SRL */
#define	BSRTOK	16	/* BIT, SET, RES */
#define	JPTOK	17	/* JP */
#define	JRTOK	18	/* JR */
#define	DJNZTK	19	/* DJNZ */
#define	CALLTK	20	/* CALL */
#define	RETTOK	21	/* RET */
#define	RSTTOK	22	/* RST */
#define	INTOK	23	/* IN */
#define	OUTTOK	24	/* OUT */
#define	PUSHTK	25	/* PUSH, POP */
#define	EXTOK	26	/* EX */
#define	ASTOK	27	/* ADC, SBC */
#define	ADDTOK	28	/* ADD */
#define	LDTOK	29	/* LD */
#define	CONDTK	30	/* CONDITIONALS */
#define	GLOBTK	31	/* GLOBALS */
#define	SAVETK	32	/* SAVE (internal macro) */
#define	MACROT	33	/* MACROS */
#define	CDCRTK	34	/* CD, CR (internal macros) */
#define	EXTRNT	35	/* EXTERNALS */
#define	ENTRYT	36	/* ENTRY */
#define	USINGT	37	/* USING */
#define	RADIXT	38	/* RADIX */
#define	LITORT	39	/* LITORG */
#define	RSTRTK	40	/* RSTR (internal macro) */
#define	SVCTOK	41	/* SVC (internal macro) */
#define	MOVTOK	42	/* MOV (internal macro) */
#define	ISECTK	43	/* ISECT */
#define	ENDITK	44	/* ENDI */
#define	DROPTK	45	/* DROP */
#define	APUSHT	46	/* APUSH */
#define	APOPTK	47	/* APOP */
#define	CMPTOK	48	/* CMP (internal macro) */
#define	EXITOK	49	/* EXIT (internal macro) */
#define	FILLTK	50	/* FILL */
#define	RRRRSS	51	/* undocumented instructions */
#define	SETLDT	52	/* undocumented instructions */
#define	TKNAME	53	/* NAME */
#define	LNKSTK	54	/* LNKSET */
#define	LOCALT	55	/* LOCAL */
#define EJETOK	56	/* EJECT */
#define	LINK	57	/* link request */
#define	HEADER	58	/* new header on listing */
#define	STOPIT	59	/* stop assembly function (NOT implemented) */
#define	SCREEN	60	/* display to screen (NOT implemented) */
#define	DUALON	61	/* dual routing on (NOT implemented) */
#define	DUALOF	62	/* dual routine off (NOT implemented) */
#define	QUITIT	63	/* abort assembly function (NOT implemented) */
#define	PRINTV	64	/* ADISP function */
#define	REFER	65	/* reference function */
#define	INCLUD	66	/* include function */
#define	EXTERN	67	/* EXT file function */
#define	PRINT	68	/* listing control */
#define	ROBJ	69	/* object file name function */
#define	PATCH	70	/* patch function */
#define	GLINK	71	/* link global file request */
#define	VERSN	72	/* version number on listing (NOT implemented) */
#define	XLOAD	73	/* want load headers (NOT implemented) */
#define	YLOAD	74	/* don't want load headers (NOT implemented) */
#define	LIB	75	/* link library request */
#ifdef HITACHI
#define	TSTTOK	76	/* hitachi 64180 extended instructions */
#define	MLTTOK	77	/* hitachi 64180 extended instructions */
#define	IN0	78	/* hitachi 64180 extended instructions */
#endif


/*	tokens for the PRINT pseudo-op		*/
#define	ON	1	/* print on (default) */
#define	OFF	2	/* print off */
#define	ALL	3	/* print everything */
#define	MACP	4	/* print macro expansions (default) */
#define	CON	5	/* print conditionals */
#define	LONG	6	/* print long object (default) */
#define	SHORT	7	/* print short object */
#define	NOMAC	8	/* don't print macro expansions */
#define	NOCON	9	/* don't print conditionals (default) */




/*	tokens for APUSH/APOP pseudo-ops	*/
#define	UUSING	1	/* using token */
#define	UPRINT	2	/* print token */




/*	misc tokens	*/
#define	CONBIT	0x80	/* operand is conditional */
#define	COMTTK	'*'	/* token for block comment */
#define	INTTOK	0x90	/* operand token for INTEGER */
#define	LITTOK	0xa0	/* litorg literals */
#define	CTOK	0x71	/* token for uncondit opnd kw 'C' */
#define	CCOND	0x8b	/* token for conditional opnd kw 'C' */



/*	conditional definitions		*/
#define	IFTRUE		0
#define	IFFALSE		1
#define	IFZERO		2
#define	IFNZERO		3
#define	IFPOS		4
#define	IFNEG		5
#define	IFDEF		6
#define	IFNDEF		7
#define	IFELSE		8
#define	IFENDIF		9
#define	SPECIALIF	10

/*	cross reference structure	*/
#define	REFF	struct reff

struct	reff
{
	short	r_line;
	short	r_file_no;
	REFF	*r_link;
};

#define	RSIZE	sizeof (REFF)


/*	symbol table structure	*/
#define	SYM	struct sym

struct sym
{
	unsigned char	s_name[20];
	unsigned char	s_flag1;
	unsigned char	s_flag2;
	unsigned char	s_isect;
	unsigned char	s_psect;
	unsigned short	s_value;
	SYM	*leftptr;
	SYM	*rightptr;
	REFF	*ref_beg;
	REFF	*ref_end;
};

#define	SSIZE	sizeof (SYM)



/*	lookup tables structure	*/
#define	TABLE	struct	table

struct	table
{
	unsigned char	t_name[8];
	unsigned char	t_token;
	unsigned char	t_operands;
	unsigned char	t_value;
};

/*
 *	structure for table lookup of "print" options
 */
#define PRTLST struct printlst

struct printlst
{
	unsigned char	p_name[6];
	unsigned char	p_token;
};

/*
 *	structure for apush table
 */
#define APUSHLST struct apushlst

struct apushlst
{
	unsigned char	a_name[6];
	unsigned char	a_token;
};

/*
 *	register to bracket register structure
 */
#define	BRACK	struct	brack

struct	brack
{
	unsigned char	b_tok1;
	unsigned char	b_tok2;
};


/*	register token structure	*/
#define	REG	struct	regfunc

struct	regfunc
{
	unsigned char	r_name[5];
	unsigned char	r_token;
};


#define MACTX struct mac_text

struct mac_text
{
	MACTX		*mtx_next;
	unsigned char	*mtx_text;
};

#define MTSIZE sizeof(MACTX)


/*	macro structure		*/
#define	MAC	struct	macrox
#define MXDDEF	1			/* double defined macro flag */
#define MXDDRD	2			/* double defined macro error reported */

struct	macrox
{
	char	*mx_name;
	unsigned char	mx_flag;
	char	*mx_param;
	MACTX	*mx_text;
	MAC	*mx_left;
	MAC	*mx_right;
};


#define	MSIZE	sizeof (MAC)




/*	litorg literals structure	*/
#define	LIT	struct	litx

struct	litx
{
	unsigned short	l_number;
	unsigned char	l_text[80];
};

#define	LSIZE	sizeof (LIT)





/*.
*************************************************************************
*									*
*	structures for eval.c						*
*									*
*************************************************************************
*/

/*
 *	evaluation stack structure
 */
#define	EVAL	struct	evlstk

struct	evlstk
{
	short	e_value;
	unsigned char	e_relo;
};

/*
 *	expression math functions structure
 */
#define	MATH	struct	matfunc

struct	matfunc
{
	unsigned char	m_name[5];
	unsigned char	m_token;
};


#define	SMATH	struct	smatfunc

struct	smatfunc
{
	unsigned char	sm_name[2];
	unsigned char	sm_token;
};


#include <time.h>
#include "functions.h"

/*	xs_cat.c

	CAT for Samarux.

	Concatenate files.

	Copyright (c) 2007 - 2015 Miguel I. Garcia Lopez.

	This program is free software; you can redistribute it and/or modify it
	under the terms of the GNU General Public License as published by the
	Free Software Foundation; either version 2, or (at your option) any
	later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

	Usage:

	cat [-|file ...]

	File - refers to standard input.

	Examples:

	cat - schedule.txt notes.txt
	cat myfile.doc

	Changes:

	19 Dec 2014 : 1.00 : 1st version.
	24 Dec 2014 : 1.01 : Minor changes.
*/

CatMain(argc, argv)
int argc, argv[];
{
	int i;

	/* Check arguments */

	if(argc == 1)
		CatOut("-");
	else
	{
		for(i = 1; i < argc; ++i)
		{
			if(CatOut(argv[i]))
				return 1;
		}
	}

	return 0;
}

CatOut(fn)
char *fn;
{
	FILE *fp;
	int ch;

	/* Open */

	if(*fn == '-' && !fn[1])
		fp = stdin;
	else if((fp = fopen(fn, "r")) == NULL)
		return ErrorOpen();

	/* Write */

	while((ch = fgetc(fp)) != EOF)
		putchar(ch);

	/* Close */

	if(fp != stdin)
		fclose(fp);

	/* Success */

	return 0;
}


/*	File:	grp32.c
 *
 *	Contains:	grp32
 *
 *	This is the handler for the SAVE assembler macro.
 */



#include "asm.h"




static char s1[] =
{
	0x8,
	0xf5,
	0x8,
	0
};


static char s2[] =
{
	0xd9,
	0xc5,
	0xd5,
	0xe5,
	0xd9,
	0
};


static char s3[] =
{
	0xdd,	0xe5,
	0xfd,	0xe5,
	0
};


static char s4[] =
{
	0xf5,
	0
};


static char s5[] =
{
	0xc5,
	0xd5,
	0xe5,
	0
};




void grp32(token)
register int token;
{
#if DEBUG
printf("group 32\n");
#endif

	if (token == 0)
		savit(s5);
	else if (token == 0x90)
	{
		savit(s4);
		savit(s5);
	}
	else if (token == 0x20)
	{
		savit(s2);
		savit(s4);
		savit(s5);
	}
	else if (token == 0x80)
	{
		savit(s3);
		savit(s2);
		savit(s4);
		savit(s5);
	}
	else if (token == 0x70)
	{
		savit(s1);
		savit(s3);
		savit(s2);
		savit(s4);
		savit(s5);
	}
	else
		dnops();
}





/*
 *	This the is handler for RSTR assembler macros.
 */



static char r5[4] =
{
	0xe1,
	0xd1,
	0xc1,
	0
};



static char r4[2] =
{
	0xf1,
	0
};




static char r3[5] =
{
	0xfd,	0xe1,
	0xdd,	0xe1,
	0
};




static char r2[6] =
{
	0xd9,
	0xe1,
	0xd1,
	0xc1,
	0xd9,
	0
};



static char r1[4] =
{
	0x8,
	0xf1,
	0x8,
	0
};



void grp40(token)
register int token;
{
#if DEBUG
printf("group 40\n");
#endif
	if (token == 0)
		savit(r5);
	else if (token == 0x90)
	{
		grp40(0);
		savit(r4);
	}
	else if (token == 0x20)
	{
		grp40(0x90);
		savit(r3);
	}
	else if (token == 0x80)
	{
		grp40(0x20);
		savit(r2);
	}
	else if (token == 0x70)
	{
		grp40(0x80);
		savit(r1);
	}
	else
		dnops();
}





/*
 *	Handler for the EXIT assembler macro.
 */

void grp49(token)
register int token;
{
#if DEBUG
printf("group 49\n");
#endif

	if (token == 0 || token == 0x90 || token == 0x20 ||
	   token == 0x70 || token == 0x80)
	{
		grp40(token);
		asscod[ascdno++] = 0xC9;
	}
	else
		dnops();
}

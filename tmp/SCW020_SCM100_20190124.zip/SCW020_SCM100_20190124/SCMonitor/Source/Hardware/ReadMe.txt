; This folder contains a sub-folder for each distinct class of hardware


; Supported hardware (## = Configuration code)

##  Decription       ID    Name       CPU
==  ==========       ==    ====       ===

0#  Custom           0     Custom     --
L#  LiNC80_Z80       5     LiNC80     Z80
R#  RC2014_Z80       3     RC2014     Z80
S1  SC101_Z80        4     SC101      Z80
S2  SC114_Z80        8     SC114      Z80
S3  SC_S3            10    SC108      Z80
S4  SC_S4            11    SC111      Z180
T1  TomsSBC_Z80      6     TomsSBC    Z80
W#  Simulated_Z80    1     Simulated  Z80
Z1  Z280RC_Z280      7     Z280RC     Z280
Z2  Z80SBCRC_Z80     9     Z80SBCRC   Z80
--  SCDevKit01_Z80   2     SCDevKit01 Z80

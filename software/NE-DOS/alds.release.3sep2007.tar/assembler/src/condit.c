/*
 *	This is the handler for the assembler conditionals.
 */




#include "asm.h"

extern	MACTX	*mxp;



void grp30()
{
	int	cond, tok;
	unsigned char	*stack;
	short	value;

#if DEBUG
printf("group 30\n");
#endif


	value = odint1;
	cond = 0;
	conflg = 1;


	tok = ortkbf[1];
	
	if (tok == IFTRUE)
	{
		if (value & 1)
			cond = 1;
	}
	else if (tok == IFFALSE)
	{
		if ((value & 1) == 0)
			cond = 1;
	}
	else if (tok == IFZERO)
	{
		if (value == 0)
			cond = 1;
	}
	else if (tok == IFNZERO)
	{
		if (value)
			cond = 1;
	}
	else if (tok == IFPOS)
	{
		if (!(value < 0))
			cond = 1;
	}
	else if (tok == IFNEG)
	{
		if (value < 0)
			cond = 1;
	}
	else if (tok == IFDEF)
	{
		if (value)
			cond = 1;
	}
	else if (tok == IFNDEF)
	{
		if (value == 0)
			cond = 1;
	}
	else if (tok == SPECIALIF)
	{
		if (value > 0)
			cond = 1;
	}
	else if (tok == IFELSE)
	{
		if ((ifcnt - 1) < 0)
		{
			syncon();
			return;
		}

		if ((ifcnt - 1) != 0)
		{
			stack = ifstk;
			value = 0;

			while(value++ < ifcnt)
			{
				if (*stack++)
					return;
			}
		}

		if (false_condit)
			lstoff &= CONON;
		else
			lstoff |= CONOFF;

		if (print_con)
			lstoff &= CONON;

		condi1 = false_condit ? 0 : 1;
		false_condit = 1;
		return;
	}
	else if (tok == IFENDIF)
	{
		if ((ifcnt - 1) < 0)
		{
			syncon();
			return;
		}

		if ((ifcnt - 1) == 0)
		{
			false_condit = 1;
			ifcnt = 0;
			condi1 = 0;
			ifstk[0] = 0;
			lstoff &= CONON;
			lstln();
			dont = 1;
			conflg = 0;
			return;
		}

		--ifcnt;
		condi1 = ifstk[ifcnt];
		false_condit = 1;
		ifstk[ifcnt] = 0;
		lstoff &= CONON;
		return;
	}
	else
	{
		conflg = 0;
		dnops();
		return;
	}

	if (cond == 1)
		lstoff &= CONON;
	else
		lstoff |= CONOFF;

 	if (print_con)
		lstoff &= CONON;

	ifstk[ifcnt++] = false_condit;

	if (false_condit)
		return;

	condi1 = cond ? 0 : 1;
	false_condit = 1;

}



void syncon()
{
	int	tempx;

	eror('C');
	tempx = lstoff;
	false_condit = 0;
	condi1 = 0;
	ifcnt = 0;
	condi1 = 0;
	ifstk[0] = 0;
	conflg = 0;
	lstoff = 0;
	lstln();
	lstoff = tempx & CONON;
	dont = 1;
}

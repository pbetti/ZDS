
/*	File:	link.h
 *
 *	Z80 Linker equates, definitions, and macros.
 */

#include <stdio.h>
#ifdef M68000
#include <void.h>
#endif


/*	following are general (in nature) equates	*/
#define	BYTMSK	((unsigned char) 0xff)
#define	FATAL	1
#define	WARNING	2
#define	MAXREF	15
#define	MAXOBJ	((unsigned) 252)
#define	MAXLINE	61
#define	BASE_ADDRESS	((unsigned) 0x3000)




/*	following are the definations for what the linker is doing	*/
#define	ORG_TOKEN	1
#define	DATA_TOKEN	2
#define	LIST_TOKEN	3
#define	NAME_TOKEN	4
#define	LOAD_TOKEN	5
#define	INCLUDE_TOKEN	6
#define	DPAGE_TOKEN	7
#define	END_TOKEN	8
#define	GLOBAL_TOKEN	9
#define	DEFINE_TOKEN	10
#define	FILL_TOKEN	11
#define	DUMMY		100




/*	following are the link symbol flag byte definitions	*/
#define	LNKDSP	1
#define	LNKUND	2
#define	LNKMDF	4
#define	LNKLIB	0x10
#define	LNKGBL	0x20
#define	LNKEXT	0x40
#define	LNKENT	0x80
#define	LIBMSK	(LNKLIB | LNKEXT)
#define	DEFMSK	(LNKENT | LNKEXT)
#define	INTERN	(LNKENT | LNKGBL)
#define	isdefined(x)	((((x) & DEFMSK) == DEFMSK) || fullflag)
#define	defines(x)	((((x) & DEFMSK) == DEFMSK) || (((x) & INTERN) == LNKENT) || fullflag)



/*	following are the 06 header flag byte definitions	*/
#define	O6DSEG	4	/* following contains dsegs */
#define	O6LNK	8	/* following contains a LINK filename */
#define	O6ENT	0x10	/* following contains ENTRYs */
#define	O6GBL	0x20	/* following is a GBL file */
#define	O6EXT	0x40	/* following contains EXTERNals */
#define	O6REL	0x80	/* following is relocatable object */



/*	following are the 04 header flag byte definitions	*/
#define	O4NONE	0	/* use NEITHER lsb or msb */
#define	O4MSB	1	/* use msb only */
#define	O4LSB	2	/* use lsb only */
#define	O4FULL	3	/* use BOTH lsb and msb */
#define	O4OBJR	4	/* object is relocatable */
#define	O4OBJ	8	/* object code is present */
#define	O4ABS	0x10	/* address is absolute (reloc code only) */
#define	O4DSEG	0x20	/* name is a dseg */
#define	O4EXT	0x40	/* EXTERNal name present */
#define	O4ENT	0x80	/* ENTRY name present */
#define	relocatable(x)	((((x) & O4ABS) == 0) && ((x) & O4OBJR))



/*	following are the 09 header flag byte definitions	*/
#define	O9GBL	0x10	/* global file request */
#define	O9LNK	0x20	/* link file request */
#define	O9LIB	0x40	/* library file request */




/*	header bytes	*/
#define	O1H	1	/* 01 header byte */
#define	O2H	2	/* 02 header byte */
#define	O3H	3	/* 03 header byte */
#define	O4H	4	/* 04 header byte */
#define	O6HC	5	/* 06 header byte (aseg) */
#define	O6H	6	/* 06 header byte (relocatable) */
#define	O7H	7	/* 07 header byte (defs) */
#define	O8H	8	/* 08 header byte */
#define	O9H	9	/* 09 header byte */
#define	OAH	10	/* 0A header byte */
#define	OBH	11	/* 0B header byte */
#define	OMAX	12	/* lowest illegal header byte */



/*	link flag definitions	*/
#define	LADIS	1	/* address discontinuity */



/* modes of the linker */
#define	CSEG	0
#define	DSEG	1



/*	symbol table structure	*/

struct sym
{
	unsigned char	name[20];
	unsigned short	value;
	unsigned char	flag;
	struct refx	*nxtref;
	struct sym	*nxtsym;
};

#define	SYM	struct sym
#define	SYMNUL	(SYM *)0
#define	SYMSIZ	sizeof (SYM)




/*	global table structure	*/
#define	GBL	struct gblx

struct gblx
{
	char	g_name[20];
	char	g_flag1;
	char	g_flag2;
	char	g_isect;
	char	g_psect;
	short	g_value;
	SYM	*leftptr;
	SYM	*rightptr;
	char	*ref_beg;
	char	*ref_end;
};

#define	GSIZE	sizeof (GBL)




/*	cross refference table structure	*/
struct refx
{
	unsigned int	value;
	struct	refx	*nextref;
};

#define	REF	struct refx
#define	REFNUL	(REF *)0
#define	REFSIZ	sizeof (REF)





/*	psect table structure	*/
struct pstbl
{
	unsigned char	name[8];
	unsigned char	flag;
	unsigned int	value;
	struct	pstbl	*nxtp;
};

#define	PSECT	struct pstbl
#define	PSNUL	(PSECT *)0
#define	PSSIZ	sizeof (PSECT)

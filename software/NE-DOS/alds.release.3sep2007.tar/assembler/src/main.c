/*	File:	main.c
 *
 *	Contains:	main
 *
 *	This is the main entry point into the assembler.
 */



#include "asm.h"
#include <sys/types.h>
#include <sys/times.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>

extern	char	chkhed_sw;
extern	char	errname[];
extern	LIT	litbuf[];
extern	int	didinclude;
extern	int	start_count;
extern	int	symnum;
extern	SYM	*start_fp;
extern	FILE	*efile;
extern	int	gfile;
extern	FILE	*oefile;

static	struct tms	tpoint;
static	int		add_mail = 0;
static	int		loop_flag = 0;
static	FILE		*mp = 0;
static	char		lockbuf[50];
static	int		lock;
static	int		delete;
static	char		lisxbuf[100];
static	char		cmdbuf[100];
static	char		who[30];
static	char		hold[] = "/tmp/#alasmXXXXXX";
static	char		imdname[] = "/tmp/#alasmXXXXXX";
static	char		alocname[] = "/tmp/#alasmXXXXXX";
int	alocfile;

char	finame[30];
char	dirname[150];
char	ldirname[150];
char	eabort;

int	erabort;
int	errmail;
int	mail;
int	pass1;
int	prtyes;
int	xkill;
int	xobjno;
int	xquiet;
int	xrefno;
int	xrefyes;
int	xscreen;
int	verbose;
int	atruncate;

int	mperl = 9;
int	sperl = 10;
int	ObjBytes = MAXOBJ;
time_t	sttime;
time_t	sptime;

extern	short	litxnum;


/*.
*************************************************************************
*									*
*	main								*
*	----								*
*									*
*									*
*									*
*									*
*************************************************************************
*/
main(argc, argv)
int	argc;
char	**argv;
{
	register char	*bp, *dir;
	register unsigned char	*sp;
		 int	printflag = 0;
		 int	deleteflag = 0;
		 int	errorflag = 0;
		 int	ldir = 0;
		 int	c;
		 char	tbuff[50];
		 char	timexx[30];
	extern	int	optind;
	extern	char	*optarg;



	if (geteuid() == 0)
		(void) nice(-4);
	else
		(void) nice(4);

	(void) strcpy(dirname, "");
	(void) strcpy(ldirname, "");
	dir = 0;

	if (argc < 2)
	{
nogood:
		printf("\nUsage:  alasm [options] filename\t\tSee 'man alasm' for options\n\n");
		exit(1);
	}

/*.
*************************************************************************
*									*
*	getopt options and varable definitions				*
*									*
*	option	variable	definition				*
*									*
*	f	fast		no listing				*
*					turns 'printflag' off		*
*					turns 'xrefno' on		*
*					turns 'xrefyes' off		*
*	c	rlist							*
*	l	dolog		put all screen output into log file	*
*	p	printflag						*
*	d	deleteflag						*
*					turns 'printflag' on		*
*	a#	erabort							*
*	e	errorflag						*
*					turns 'printflag' on		*
*	P	pass1		print pass1 listing			*
*					turns 'fast' off		*
*	s	xrefno							*
*	x	xrefyes							*
*					turns 'xrefno' off		*
*					turns 'fast' off		*
*	o	xobjno		do not make object file			*
*	r	prtyes							*
*	m	mail							*
*	S	xscreen							*
*					turns 'fast' off		*
*	q	xquiet							*
*					turns 'log' off			*
*					turns 'xscreen' off		*
*	M	errmail		send mail only if errors		*
*									*
*	k	xkill		kill object file if error		*
*									*
*	t	truncate	truncated 80 col listing		*
*				    sets mperl = 8			*
*				    sets sperl = 5			*
*************************************************************************
*/
	slenth = 14;	/* set length of a symbol */

	while((c = getopt(argc, argv, "fclpda:ePsxormS:XqMkvtO:LDb:")) != EOF)
	{
		switch(c)
		{
		case 'f':
			fast = 1;
			printflag = 0;
			break;

		case 'c':
			rlist = 1;
			break;

		case 'l':
			dolog = 1;
			break;

		case 'p':
			printflag = 1;
			break;

		case 'd':
			deleteflag = 1;
			printflag = 1;
			break;

		case 'a':
			erabort = atoi(optarg);
			eabort = 1;
			break;

		case 'e':
			errorflag = 1;
			printflag = 1;
			break;

		case 'P':
			pass1 = 1;
			fast = 0;
			break;

		case 's':
			xrefno = 1;
			break;

		case 'x':
			xrefyes = 1;
			fast = 0;
			xrefno = 0;
			break;

		case 'o':
			xobjno = 1;
			break;

		case 'r':
			prtyes = 1;
			break;

		case 'm':
			mail = 1;
			break;

		case 'X':
			xscreen = 1;
			break;

		case 'q':
			xquiet = 1;
			dolog = 0;
			xscreen = 0;
			break;

		case 'M':
			errmail = 1;
			break;

		case 'k':
			xkill = 1;
			break;

		case 'v':
			verbose = 1;
			break;

		case 't':
			atruncate = 1;
			break;

		case 'O':
			dir = optarg;
			strcpy(dirname, dir);

			if(dirname[strlen(dirname) - 1] != '/')
				strcat(dirname, "/");

			break;

		case 'L':
			ldir = 1;
			break;

		case 'D':
			delete = 1;
			break;

		case 'S':
			slenth = atoi(optarg);

			if(slenth < 6)
				slenth = 6;
			else if(slenth > 19)
				slenth = 19;

			break;

		case 'b':
			ObjBytes = atoi(optarg);

			if(ObjBytes < 10)
				ObjBytes = 10;
			else if(ObjBytes > 252)
				ObjBytes = 252;

			break;

		default:
			(void) fprintf(stderr, "Unknown option %c\n", c);
			exit(1);
		}
	}


	if (optind == argc)
		goto nogood;

	if (fast)
		printflag = 0;

	if (signal(SIGINT, SIG_IGN) != SIG_IGN)
	{
#ifdef M68000
		(void) signal(SIGINT, onintr);
		(void) signal(SIGQUIT, onintr);
		(void) signal(SIGHUP, onintr);
		(void) signal(SIGKILL, onintr);
#else /*M68000*/
		(void) signal(SIGINT, (__sighandler_t *)onintr);
		(void) signal(SIGQUIT, (__sighandler_t *)onintr);
		(void) signal(SIGHUP, (__sighandler_t *)onintr);
		(void) signal(SIGKILL, (__sighandler_t *)onintr);
#endif /*M68000*/
	}

	(void) strcpy(who, getenv("USER"));

	if(dir && ldir)
		(void) strcpy(ldirname, dirname);

	for(; optind < argc;)
	{
		bp = argv[optind];
		(void) strcpy(alocname, hold);
		alocfile = creat(mktemp(alocname), 0666);
		passno = 1;
		gettime();
		(void) time(&sttime);
		(void) strcpy(timexx, timeb);
		(void) strcpy(tx3, bp);
		(void) strcpy(savebuf, bp);
		sp = look(tx3);
		(void) strcpy(tx2, sp);

		if (sp = search(tx2))
			*sp = 0x00;

		(void) strcpy(pbuffr, tx2);
		sp = tx2;

		if (search(savebuf) == 0)
		{
			if (tx2[0] >= 'A' && tx2[0] <= 'Z')
				(void) strcat(savebuf, ".SRC");
			else
				(void) strcat(savebuf, ".src");
		}

		if(verbose)
		{
			printf("%s\n", savebuf);
			(void) fflush(stdout);
		}

		while (*sp)
		{
			*sp = atolower(*sp);
			sp++;
		}

		(void) sprintf(objname, "%s%s", dirname, tx2);
		(void) sprintf(finame, "%s.gbl", tx2);
		(void) sprintf(lisxbuf, "%s%s.lis", ldirname, tx2);
		(void) sprintf(tbuff, "%s.log", tx2);
		(void) sprintf(lockbuf, "%s.lock", tx2);
		++optind;

		if (access(lockbuf, 0) == 0)
			goto bad;

		if ((lock = creat(lockbuf, 0)) < 0)
		{
bad:
			printl("alasm: file competition (lock file). aborting assembly.\n");
			exit(1);
		}


		if ((infile = tryopen(savebuf)) == NULL)
		{
			printl("\nCan't open Source file: %s\n", savebuf);
			xdone(1);
		}

		(void) strcpy(imdname, hold);

		if ((imdfile = xcreate(mktemp(imdname))) == NULL)
		{
			printl("\nCan't create intermediate file\n");
			xdone(1);
		}

		if (xscreen)
		{
			fast = 0;
			lisfile = stderr;
			atruncate = 1;
		}
		else
		{
			if (fast == 0 && (lisfile = xcreate(lisxbuf)) == 0)
			{
				printl("\nCan't create listing file\n");
				xdone(1);
			}
		}

		if (atruncate)
		{
			sperl = 5;
			mperl = 8;
		}

		if (fast)
		{
			/*
			 *	if no listing, then no cross refference
			 */
			xrefno = 1;
			xrefyes = 0;
		}

		if (dolog && (logfile = xcreate(tbuff)) == 0)
		{
				printl("\nCan't create log file\n");
				xdone(1);
		}
		

	/*
	 *	pass 1
	 */
	 
		passx();

		if (xobjno == 0)
		{
			(void) strcat(objname, (mode == ASEG) ? ".hex" : ".rel");

			if ((objfile = xcreate(objname)) == 0)
			{
				printl("\nCan't create object file\n");
				xdone(1);
			}
		}

		printl("Pass 1 Complete");

		if (dolog)
		{
			gettime();
			printl(" at: %s\n", timeb);
			(void) fflush(logfile);
		}
		else
			printl("\n");
		

	/*
	 *	do pass 2
	 */
	 
		rewind(infile);
		rewind(imdfile);
		passno = 2;
		passx();
		
		if (lisfile && !xrefyes)
		{
			lfeed();
			lfeed();
		}

		if (errcnt)
			(void) sprintf(lline, "%u", errcnt);
		else
			(void) strcpy(lline, "No");

		(void) strcat(lline, " Assembly Error");

		if (errcnt != 1)
			(void) strcat(lline, "s");

		(void) sprintf(cmdbuf, "%s", lline);

		if (lisfile && !xrefyes)
		{
			fprintf(lisfile,"%s",lline);
			lfeed();
			lfeed();
		}
		
		printl("%s\n", lline);

		if (fast)
		{
			printl("Pass 2 Complete\n");
			goto finish;
		}


		if (errcnt && lisfile && !xrefyes)
			prterr();

		gettime();
		(void) time(&sptime);
		sptime -= sttime;
		(void) sprintf(lline, "Start: %s\t\tStop: %s\t\tElapsed: %8.8s", timexx, timeb, asctime(gmtime(&sptime))+11);	

		if (dolog)
			printl("%s\n", lline);

		if (lisfile && !xrefyes)
		{
			(void) fprintf(lisfile,"%s",lline);
			lfeed();
			times(&tpoint);
			sttime = tpoint.tms_utime / 60;
			sptime = tpoint.tms_stime / 60;

			if (sttime && !sptime)
				sptime = 1;

			(void) sprintf(tx2,"%8.8s", asctime(gmtime(&sttime))+11);
			(void) sprintf(tx3,"%8.8s", asctime(gmtime(&sptime))+11);
			(void) sprintf(lline, "(%s user, %s system)", tx2, tx3);
			(void) fprintf(lisfile,"%s",lline);
			lfeed();
		}

		if (xrefno == 0 && lisfile)
		{
			xrefyes = 0;
			change();
			lsymt();
		}

		printl("Pass 2 Complete");

		if (dolog)
		{
			gettime();
			printl(" at: %s\n", timeb);
			(void) fflush(logfile);
		}
		else
			printl("\n");

		if (printflag)
		{
			if (errorflag && errcnt)
				printl("alasm: Listing NOT printed due to errors\n");
			else
			{
				(void) fclose(lisfile);
				lisfile = 0;
				(void) strcpy(tx1, "lpr -X ");

				if (deleteflag)
					(void) strcat(tx1, "-r ");

				(void) strcat(tx1, lisxbuf);
				printl("%s\n", tx1);
				(void) system(tx1);
			}
		}

finish:
		if(argv[optind] || loop_flag)
		{
			if(errcnt)
				printf("%s\n", cmdbuf);

			freeup();		/* free up allocated memory */
			addmail(0);
			loop_flag = 1;
		}
		else
			checkmail(0);

		frstsw = 0;			/* clear first time 06 flag */
		macnum = 0;			/* no macros */
		macbeg = macend = 0;		/* clear macro table */
		symcnt = 0;			/* no symbols */
		opnrec = 0;			/* no open record
		litcnt = 0;			/* clear literal counter */
		litxnum = 0;			/* clear literal number */
		symbeg = 0;			/* clear symbol pointer */
		litbeg = litend = litbuf;	/* reset literals */
		start_count = 0;
		start_fp = 0;
		symnum = 0;
		chkhed_sw = 0;
		didinclude = 0;

		if(delete && !errcnt)
			(void) unlink(lisxbuf);
	}

	if(add_mail)
		outmail();

	unlock();
	exit(errcnt ? 1 : 0);
}


/*.
*************************************************************************
*									*
*	xdone								*
*	-----								*
*									*
*									*
*									*
*									*
*************************************************************************
*/
void xdone(number)
{
	if(add_mail)
		addmail(number);
	else
		checkmail(number);

	exit((number || errcnt) ? 1 : 0);
}


void checkmail(number)
int	number;
{
	int	xx = errcnt;

	unlock();
	gettime();

	if (mail || errmail)
	{
		if (number)
		{
			(void) sprintf(cmdbuf, "Assembly of %s aborting abnormally during pass %u on: %s at: %s", savebuf, passno, dateb, timeb);
			mailit();
		}
		else if (mail || errcnt)
		{
			if(xx < 0)
				xx = 0;

			(void) sprintf(cmdbuf, "Assembly of %s complete with %u errors on: %s at: %s", savebuf, xx, dateb, timeb);
			mailit();
		}
	}
}


/*.
*************************************************************************
*									*
*	onintr								*
*	------								*
*									*
*									*
*									*
*									*
*************************************************************************
*/
onintr(signo)
int	signo;
{
	unlock();

	if (signo == SIGQUIT)
#ifdef M68000
		(void) signal(SIGQUIT, onintr);
#else /*M68000*/
		(void) signal(SIGQUIT, (__sighandler_t *)onintr);
#endif /*M68000*/

	gettime();
	printl("\nAssembly interrupted on: %s at: %s\n", dateb, timeb);

	if (mail || errmail)
	{
		(void) sprintf(cmdbuf, "Assembly of %s interrupted on: %s at: %s\n", savebuf, dateb, timeb);
		mailit();
	}

	exit(1);
}


/*.
*************************************************************************
*									*
*	unlock								*
*	------								*
*									*
*									*
*									*
*									*
*************************************************************************
*/
void
unlock()
{
	if (lock)
	{
		(void) close(lock);
		lock = 0;
		(void) unlink(lockbuf);
	}

	if (infile)
	{
		(void) fclose(infile);
		infile = 0;
	}
	
	if (errfile)
	{
		(void) fclose(errfile);
		(void) unlink(errname);
		errfile = 0;
	}
	
	if (imdfile)
	{
		(void) fclose(imdfile);
		(void) unlink(imdname);
		imdfile = 0;
	}
	
	if (objfile)
	{
		(void) fclose(objfile);
		objfile = 0;

		if (errcnt && xkill)
			(void) unlink(objname);
	}

	if(alocfile)
	{
		(void) close(alocfile);
		(void) unlink(alocname);
		alocfile = 0;
	}

	if(lisfile && lisfile != stderr)
		(void) fclose(lisfile);

	lisfile = 0;

	if(logfile)
	{
		(void) fclose(logfile);
		logfile = 0;
	}

	if(efile)
	{
		(void) fclose(efile);
		efile = 0;
	}

	if(gfile)
	{
		(void) close(gfile);
		gfile = 0;
	}

	if(oefile)
	{
		(void) fclose(oefile);
		oefile = 0;
	}
}


/*.
*************************************************************************
*									*
*	mailit								*
*	------								*
*									*
*									*
*									*
*									*
*************************************************************************
*/
void mailit()
{
	char	mailbuf[200];

#ifdef M68000
	(void) sprintf(mailbuf, "mail %s <<xx\n%s\nxx\n", who, cmdbuf);
#else
	(void) sprintf(mailbuf, "mail -s \"alasm results\" %s <<xx\n%s\nxx\n", who, cmdbuf);
#endif
	(void) system(mailbuf);
}




void freeup()
{
	char	*size;

	(void) lseek(alocfile, 0L, 0);

	while(read(alocfile, &size, sizeof(char *)))
		free(size);

	(void) close(alocfile);
	(void) unlink(alocname);
	alocfile = 0;
}



char *xalloc(size)
int	size;
{
	char	*xsize;

	xsize = calloc(size, 1);
	(void) write(alocfile, &xsize, sizeof(char *));
	return(xsize);
}


void addmail(number)
int	number;
{
	int	xx = errcnt;

	unlock();
	gettime();


	if (mail || errmail)
	{
		if(mp == 0)
			mp = fopen(".axtemp", "w+");

		if (number)
			(void) fprintf(mp, "Assembly of %s aborting abnormally during pass %u on: %s at: %s", savebuf, passno, dateb, timeb);
		else if ((mail) || (errcnt))
		{
			if (xx < 0)
				xx = 0;

			(void) fprintf(mp, "Assembly of %s complete with %u errors on: %s at: %s\n", savebuf, xx, dateb, timeb);
		}

		(void) fflush(mp);
		add_mail = 1;
	}
}


void outmail()
{
	char	gbuff[150];
	char	*pnt;


	rewind(mp);
	pnt = malloc(20000);
#ifdef M68000
	(void) sprintf(pnt, "mail %s <<xx\n", who);
#else
	(void) sprintf(pnt, "mail -s \"alasm results\" %s <<xx\n", who);
#endif

	while(fgets(gbuff, 150, mp))
		(void) strcat(pnt, gbuff);

	(void) fclose(mp);
	(void) strcat(pnt, "\nxx\n");
	(void) system(pnt);
	(void) unlink(".axtemp");
}

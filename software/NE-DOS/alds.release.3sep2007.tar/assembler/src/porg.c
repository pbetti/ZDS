/*	File:	porg.c
 *
 *	Contains:	porg, setpog, dephse, pphase, locat, setas
 *
 *	This is the handler for the ORG, PSECT, SETLOC, RESLOC
 *	and PAGE statements.
 */




#include "asm.h"


extern	char	lst_rel_tick;

static	long	phsflg;		/* setloc flag */



void
porg(token)
unsigned char token;
{
	unsigned char	c;

#if DEBUG
printf("porg\n");
#endif


	/*
	 * if we're in a false conditional, exit
	 */
	if (false_condit)
		return;

	/*
	 * get the second operand byte and parse
	 */
	c = ortkbf[1];

	switch (c)
	{
	case 2:
		dephse();
		return;

	case 3:		/* psect */
	case 5:		/* aseg */
	case 6:		/* dseg */
	case 7:		/* cseg */
		if (!refflg)
		{
			setas(c);
			return;
		}
		break;

	case 4:
		page = odint1;
		return;

	case 9:
		encode = odint1;
		return;
	}

	if (token == 0x99)
	{
		locat();
		return;
	}

	if (token != 0x90)
	{
		dnops();
		return;
	}

	if (c == 8)
	{
		pphase();
		return;
	}

	/* whew! we've finally decided it's really ORG */


	/*
	 * clear the SETLOC flag
	 */
	phsflg = 0;
	offset = 0;
	lst_rel_tick = ' ';

	/*
	 * set the org difference as a defs for relocatable code
	 */
	setpog(odint1);

	/*
	 * set the org value as new pc
	 */
	adrefc[mode] =
	addisr = odint1 & (unsigned) 0xffff;

	/*
	 * set address discontinuity flag
	 */
	turn_on(AFADIS | AFORG);
}


/*.
*************************************************************************
*									*
*	setpog								*
*	------								*
*									*
*	set an offset as a defs value					*
*									*
*	setpog(value)							*
*									*
*	<value> register unsigned short value				*
*									*
*									*
*************************************************************************
*/
void
setpog(value)
register unsigned short value;
{
	register unsigned short	sp;

#if DEBUG
printf("setpog\n");
#endif

	sp = (value - adrefc[mode]) & (unsigned) 0xffff;
	asscod[0] = (unsigned char) sp;
	asscod[1] = (unsigned char) sp >> 8;
	outchg = O7H;
}


/*.
*************************************************************************
*									*
*	dephse								*
*	------								*
*									*
*	dephase RESLOC handler						*
*									*
*									*
*									*
*************************************************************************
*/
void
dephse()
{
	if ((phsflg & AFASEG) == 0)
		turn_off(AFASEG);

	phsflg = 0;
	adrefc[mode] += offset;
	addisr = adrefc[mode];
	offset = 0;
	lst_rel_tick = ' ';
}


/*.
*************************************************************************
*									*
*	pphase								*
*	------								*
*									*
*	phase SETLOC handler						*
*									*
*									*
*									*
*************************************************************************
*/
void
pphase()
{
	phsflg = aflags;
	turn_on(AFASEG);
	offset = (adrefc[mode] - odint1) & (unsigned) 0xffff;
	adrefc[mode] =
	addisr = odint1 & (unsigned) 0xffff;
	lst_rel_tick = '^';
}


/*.
*************************************************************************
*									*
*	locat								*
*	-----								*
*									*
*	handle the LOCATE operation					*
*									*
*									*
*									*
*************************************************************************
*/
void
locat()
{
	register unsigned short	value;

#if DEBUG
printf("locat\n");
#endif


	if (odint2 > 256)
	{
#if DEBUG
printf("locat:\n");
#endif
		eror('V');
		odint2 = 256;
	}

	if (adrefc[mode] % odint2)
	{
		value = (odint1 + odint2) & ((~(odint2 - 1)) | 0xff00);
		value &= (unsigned) 0xffff;
		setpog(value);

		adrefc[mode] = value;
		addisr = value;
	}

	offset = 0;
	phsflg = 0;
	turn_on(AFADIS | AFORG);
	lst_rel_tick = ' ';
}


/*.
*************************************************************************
*									*
*	setas								*
*	-----								*
*									*
*	PSECT handler							*
*									*
*									*
*									*
*************************************************************************
*/

void
setas(token)
unsigned char	token;
{
	register long	temp;
		 int	c, first, flag;


	if (token == 3 && pfirst)
		++pdef;

	first = pfirst;
	pfirst = 1;
	ps = pdef;
	phsflg = 0;
	offset = 0;
	flag = 0;
	lst_rel_tick = ' ';

	if (passno == 2)
	{
		if (*labbuf)
		{
			(void) strcpy(pbuffr, labbuf);
			pbuffr[6] = 0;
		}
	}

	temp = aflags;
	dephse();
	c = (opbyt1 & 0xf0) | ((opbyt2 >> 4) & 0xf);

	if(token == 6 && mode != DSEG)
	{
		mode = DSEG;
		ptable[pdef] |= O6DSEG;

		if(first == 0)
			goto setflg;
		else
			flag = 1;
	}
	else if(token != 6 && mode == DSEG)
	{
		mode = token == 5 ? ASEG : CSEG;

		if(first == 0)
			goto setflg;
		else
			flag = 1;
	}
	else
	{
		mode = CSEG;		/* assume cseg mode */
setflg:
		aflags = temp | (AFADIS | AFORG);
	}


	if (!c)
	{
		if (first)
		{
			if (is_on(AFASEG))
			{
				eror('T');
				odint1 = 0;
			}
		}
		else
		{
			turn_off(AFASEG);
			odint1 = 0;
		}
	}
	else if (first)
	{
		if (is_off(AFASEG))
			eror('T');
	}
	else
	{
		turn_on(AFASEG);
		mode = ASEG;

		if (c != INTTOK)
		{
			dnops();
			return;
		}
	}


	/* check for ASEG */
	if (token == 5)
	{
		turn_on(AFASEG);
		mode = ASEG;
	}

	if(mode == ASEG)
		adrefc[mode] = odint1 & (unsigned) 0xffff;

	addisr = adrefc[mode];

	if (passno == 2)
		hdflag = ptable[pdef];

	if(flag && passno == 2 && objfile && mode != ASEG)
	{
		clsrec();
		putX(OBH);
		putX(mode);
	}
}
